import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Redirect, Stack, useSegments } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AppProvider } from "@/context/AppContext";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { NotificationProvider } from "@/context/NotificationContext";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

function AuthGate({ children }: { children: React.ReactNode }) {
  const { session, role, isLoading } = useAuth();
  const segments = useSegments();

  const inAuthGroup  = segments[0] === "auth";
  const inAdminGroup = segments[0] === "admin";

  if (isLoading) return null;

  // Not logged in → login
  if (!session) {
    if (!inAuthGroup) return <Redirect href="/auth/login" />;
    return <>{children}</>;
  }

  // Logged in on auth screen → redirect by role
  if (session && inAuthGroup) {
    if (role === "admin") return <Redirect href="/admin" />;
    return <Redirect href="/" />;
  }

  // Admin visiting contratista routes (not admin/* or notificaciones)
  if (role === "admin" && !inAdminGroup && segments[0] !== "notificaciones") {
    return <Redirect href="/admin" />;
  }

  return <>{children}</>;
}

function RootLayoutNav() {
  return (
    <AuthGate>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="auth/login" />
        <Stack.Screen name="auth/register" />
        <Stack.Screen name="admin/index" />
        <Stack.Screen name="admin/revision/[id]" />
        <Stack.Screen name="historial" />
        <Stack.Screen name="historial/[id]" />
        <Stack.Screen name="notificaciones" />
        <Stack.Screen
          name="profile/setup"
          options={{ headerShown: true, title: "Perfil del Contratista", headerBackTitle: "Atrás" }}
        />
        <Stack.Screen
          name="profile/edit"
          options={{ headerShown: true, title: "Editar Perfil", headerBackTitle: "Atrás" }}
        />
        <Stack.Screen
          name="payment/new"
          options={{ headerShown: true, title: "Nuevo Pago", headerBackTitle: "Atrás" }}
        />
        <Stack.Screen
          name="payment/[id]"
          options={{ headerShown: true, title: "Detalle del Pago", headerBackTitle: "Atrás" }}
        />
        <Stack.Screen
          name="payment/preview"
          options={{ headerShown: true, title: "Vista Previa", headerBackTitle: "Atrás" }}
        />
      </Stack>
    </AuthGate>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) SplashScreen.hideAsync();
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <KeyboardProvider>
              <AuthProvider>
                <AppProvider>
                  <NotificationProvider>
                    <RootLayoutNav />
                  </NotificationProvider>
                </AppProvider>
              </AuthProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
