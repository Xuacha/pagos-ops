import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/context/AuthContext";
import { NotificationBell } from "@/components/NotificationBell";
import { getAllSubmissions, Submission } from "@/lib/db";
import { useColors } from "@/hooks/useColors";
import { formatCurrency } from "@/utils/numberToWords";

type Filter = "todos" | "pendiente" | "aprobado" | "rechazado_parcial";

const ESTADO_CONFIG = {
  pendiente:         { label: "Pendiente",  color: "#f59e0b", icon: "clock"        },
  aprobado:          { label: "Aprobado",   color: "#22c55e", icon: "check-circle" },
  rechazado_parcial: { label: "Rechazado",  color: "#ef4444", icon: "x-circle"     },
} as const;

const FILTERS: { key: Filter; label: string }[] = [
  { key: "todos",            label: "Todos"    },
  { key: "pendiente",        label: "Pendiente" },
  { key: "aprobado",         label: "Aprobado"  },
  { key: "rechazado_parcial",label: "Rechazado" },
];

function SubmissionCard({ item, onPress }: { item: Submission; onPress: () => void }) {
  const colors = useColors();
  const cfg = ESTADO_CONFIG[item.estado];
  const payment = item.payment_data;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.85 : 1 },
      ]}
    >
      <View style={styles.cardTop}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.contratista, { color: colors.foreground }]} numberOfLines={1}>
            {item.contratista_nombre}
          </Text>
          <Text style={[styles.contrato, { color: colors.mutedForeground }]}>
            Contrato: {item.profile_data.numeroContrato}
          </Text>
        </View>
        <View style={[styles.estadoBadge, { backgroundColor: cfg.color + "18", borderColor: cfg.color + "44" }]}>
          <Feather name={cfg.icon as any} size={11} color={cfg.color} />
          <Text style={[styles.estadoText, { color: cfg.color }]}>{cfg.label}</Text>
        </View>
      </View>

      <View style={styles.cardBody}>
        <View style={styles.infoRow}>
          <Feather name="file-text" size={12} color={colors.mutedForeground} />
          <Text style={[styles.infoText, { color: colors.mutedForeground }]}>
            Acta #{payment.actaPagoNumero} · {payment.periodoDesde} – {payment.periodoHasta}
          </Text>
        </View>
        <Text style={[styles.amount, { color: colors.primary }]}>
          {formatCurrency(payment.valorPagoNumeros)}
        </Text>
        <Text style={[styles.infoText, { color: colors.mutedForeground }]}>
          Enviado: {new Date(item.fecha_envio).toLocaleDateString("es-CO")}
        </Text>
      </View>

      <View style={styles.cardFooter}>
        <Feather name="edit-3" size={13} color={colors.primary} />
        <Text style={[styles.reviewLink, { color: colors.primary }]}>Revisar módulo a módulo →</Text>
      </View>
    </Pressable>
  );
}

export default function AdminDashboard() {
  const { signOut, user } = useAuth();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const topPad = Platform.OS === "web" ? 20 : insets.top;

  const [all, setAll] = useState<Submission[]>([]);
  const [filter, setFilter] = useState<Filter>("todos");
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const data = await getAllSubmissions();
    setAll(data);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const shown =
    filter === "todos" ? all : all.filter((s) => s.estado === filter);

  const pendCount = all.filter((s) => s.estado === "pendiente").length;

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.primary, paddingTop: topPad + 12 }]}>
        <View style={styles.headerLeft}>
          <View style={[styles.adminBadge, { backgroundColor: "rgba(255,255,255,0.2)" }]}>
            <Feather name="shield" size={14} color="#fff" />
            <Text style={styles.adminBadgeText}>ADMINISTRADOR</Text>
          </View>
          <Text style={styles.headerTitle}>Panel de Revisión</Text>
        </View>
        <View style={{ flexDirection: "row", gap: 16, alignItems: "center" }}>
          <NotificationBell />
          <Pressable onPress={load} hitSlop={12}>
            <Feather name="refresh-cw" size={18} color="rgba(255,255,255,0.85)" />
          </Pressable>
          <Pressable onPress={signOut} hitSlop={12}>
            <Feather name="log-out" size={18} color="rgba(255,255,255,0.85)" />
          </Pressable>
        </View>
      </View>

      {/* Stats */}
      <View style={[styles.stats, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <StatPill label="Total" value={all.length} color={colors.primary} />
        <View style={[styles.statDiv, { backgroundColor: colors.border }]} />
        <StatPill label="Pendientes" value={pendCount} color="#f59e0b" />
        <View style={[styles.statDiv, { backgroundColor: colors.border }]} />
        <StatPill label="Aprobados" value={all.filter((s) => s.estado === "aprobado").length} color="#22c55e" />
        <View style={[styles.statDiv, { backgroundColor: colors.border }]} />
        <StatPill label="Rechazados" value={all.filter((s) => s.estado === "rechazado_parcial").length} color="#ef4444" />
      </View>

      {/* Filters */}
      <View style={[styles.filters, { borderColor: colors.border }]}>
        {FILTERS.map((f) => (
          <Pressable
            key={f.key}
            onPress={() => setFilter(f.key)}
            style={[
              styles.filterBtn,
              { backgroundColor: filter === f.key ? colors.primary : "transparent" },
            ]}
          >
            <Text style={[styles.filterText, { color: filter === f.key ? "#fff" : colors.mutedForeground }]}>
              {f.label}
            </Text>
          </Pressable>
        ))}
      </View>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      ) : (
        <FlatList
          data={shown}
          keyExtractor={(s) => s.id}
          contentContainerStyle={[styles.list, { paddingBottom: bottomPad + 20 }]}
          renderItem={({ item }) => (
            <SubmissionCard
              item={item}
              onPress={() => router.push({ pathname: "/admin/revision/[id]", params: { id: item.id } })}
            />
          )}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Feather name="inbox" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                No hay formularios {filter !== "todos" ? `con estado "${FILTERS.find((f) => f.key === filter)?.label}"` : ""}
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

function StatPill({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <View style={styles.stat}>
      <Text style={[styles.statNum, { color }]}>{value}</Text>
      <Text style={{ fontFamily: "Inter_400Regular", fontSize: 11, color: "#6b7280" }}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { flexDirection: "row", alignItems: "flex-end", paddingHorizontal: 16, paddingBottom: 14, gap: 12 },
  headerLeft: { flex: 1, gap: 4 },
  adminBadge: { flexDirection: "row", alignItems: "center", gap: 4, alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  adminBadgeText: { color: "#fff", fontFamily: "Inter_600SemiBold", fontSize: 10, letterSpacing: 0.5 },
  headerTitle: { color: "#fff", fontFamily: "Inter_700Bold", fontSize: 20 },
  stats: { flexDirection: "row", alignItems: "center", paddingVertical: 12, paddingHorizontal: 16, borderBottomWidth: 1 },
  stat: { flex: 1, alignItems: "center", gap: 2 },
  statNum: { fontFamily: "Inter_700Bold", fontSize: 20 },
  statDiv: { width: 1, height: 30, marginHorizontal: 4 },
  filters: { flexDirection: "row", paddingHorizontal: 12, paddingVertical: 8, gap: 6, borderBottomWidth: 1 },
  filterBtn: { flex: 1, alignItems: "center", paddingVertical: 6, borderRadius: 8 },
  filterText: { fontFamily: "Inter_500Medium", fontSize: 12 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  list: { padding: 16, gap: 12 },
  card: { borderRadius: 14, borderWidth: 1, padding: 14, gap: 10 },
  cardTop: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  contratista: { fontFamily: "Inter_700Bold", fontSize: 14 },
  contrato: { fontFamily: "Inter_400Regular", fontSize: 12 },
  estadoBadge: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6, borderWidth: 1 },
  estadoText: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
  cardBody: { gap: 3 },
  infoRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  infoText: { fontFamily: "Inter_400Regular", fontSize: 12 },
  amount: { fontFamily: "Inter_700Bold", fontSize: 14 },
  cardFooter: { flexDirection: "row", alignItems: "center", gap: 6, paddingTop: 8, borderTopWidth: 1, borderTopColor: "#e5e7eb" },
  reviewLink: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  empty: { alignItems: "center", marginTop: 60, gap: 12 },
  emptyText: { fontFamily: "Inter_400Regular", fontSize: 15, textAlign: "center" },
});
