import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/context/AuthContext";
import {
  getSubmission,
  updateSubmissionReview,
  createNotification,
  ModuloRevision,
  Submission,
  SubmissionState,
} from "@/lib/db";
import { useColors } from "@/hooks/useColors";
import { formatCurrency } from "@/utils/numberToWords";
import { hapticSuccess } from "@/utils/platform";

export default function RevisionScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user } = useAuth();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const topPad = Platform.OS === "web" ? 20 : insets.top;

  const [sub, setSub] = useState<Submission | null>(null);
  const [modulos, setModulos] = useState<ModuloRevision[]>([]);
  const [obsGeneral, setObsGeneral] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) return;
    getSubmission(id).then((s) => {
      setSub(s);
      if (s) {
        setModulos(
          s.modulos_revision.length > 0
            ? s.modulos_revision
            : s.profile_data.obligacionesContractuales.map((ob) => ({
                obligacionId: ob.id,
                obligacion: ob.obligacion,
                aprobado: null,
                observacion: "",
              }))
        );
        setObsGeneral(s.observacion_general ?? "");
      }
      setLoading(false);
    });
  }, [id]);

  const toggleModulo = useCallback((idx: number, aprobado: boolean) => {
    setModulos((prev) =>
      prev.map((m, i) =>
        i === idx ? { ...m, aprobado, observacion: aprobado ? "" : m.observacion } : m
      )
    );
  }, []);

  const setObsModulo = useCallback((idx: number, obs: string) => {
    setModulos((prev) =>
      prev.map((m, i) => (i === idx ? { ...m, observacion: obs } : m))
    );
  }, []);

  const handleSave = async () => {
    if (!sub) return;

    const rechazados = modulos.filter((m) => m.aprobado === false);
    const sinRevisar = modulos.filter((m) => m.aprobado === null);

    if (rechazados.some((m) => !m.observacion.trim())) {
      Alert.alert(
        "Observación requerida",
        "Debes escribir una observación para cada módulo rechazado."
      );
      return;
    }

    let estado: SubmissionState = "aprobado";
    if (sinRevisar.length > 0) {
      Alert.alert(
        "Módulos sin revisar",
        `Hay ${sinRevisar.length} módulo(s) sin marcar. ¿Deseas continuar? Los no marcados se dejarán como pendientes.`,
        [
          { text: "Cancelar", style: "cancel" },
          { text: "Continuar", onPress: () => doSave(estado) },
        ]
      );
      return;
    }
    if (rechazados.length > 0) estado = "rechazado_parcial";

    doSave(estado);
  };

  const doSave = async (estado: SubmissionState) => {
    if (!sub) return;
    setSaving(true);
    hapticSuccess();

    const ok = await updateSubmissionReview(sub.id, modulos, obsGeneral, estado);
    if (ok) {
      const rechazados = modulos.filter((m) => m.aprobado === false);
      const titulo =
        estado === "aprobado"
          ? "✅ Formulario aprobado"
          : `⚠️ Formulario con ${rechazados.length} observación(es)`;
      const mensaje =
        estado === "aprobado"
          ? `Tu acta #${sub.payment_data.actaPagoNumero} fue aprobada.${obsGeneral ? ` Obs: ${obsGeneral}` : ""}`
          : `Tu acta #${sub.payment_data.actaPagoNumero} tiene observaciones en ${rechazados.length} módulo(s). Revisa el historial.`;

      await createNotification(sub.contratista_id, titulo, mensaje, estado === "aprobado" ? "aprobado" : "rechazado");
    }

    setSaving(false);
    if (ok) {
      Alert.alert("Guardado", "La revisión fue guardada y el contratista fue notificado.", [
        { text: "OK", onPress: () => router.back() },
      ]);
    } else {
      Alert.alert("Error", "No se pudo guardar la revisión. Verifica tu conexión.");
    }
  };

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} size="large" />
      </View>
    );
  }
  if (!sub) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.mutedForeground }}>Formulario no encontrado</Text>
      </View>
    );
  }

  const payment = sub.payment_data;

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.primary, paddingTop: topPad + 12 }]}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Feather name="arrow-left" size={22} color="#fff" />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerName} numberOfLines={1}>{sub.contratista_nombre}</Text>
          <Text style={styles.headerSub}>
            Acta #{payment.actaPagoNumero} · {payment.periodoDesde} – {payment.periodoHasta}
          </Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={[styles.body, { paddingBottom: bottomPad + 100 }]}>
        {/* Summary */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.primary }]}>Información del pago</Text>
          <InfoRow label="Contratista" value={sub.contratista_nombre} colors={colors} />
          <InfoRow label="Contrato" value={sub.profile_data.numeroContrato} colors={colors} />
          <InfoRow label="Secretaría" value={sub.profile_data.secretaria} colors={colors} />
          <InfoRow label="Valor" value={formatCurrency(payment.valorPagoNumeros)} colors={colors} />
          <InfoRow label="Período" value={`${payment.periodoDesde} – ${payment.periodoHasta}`} colors={colors} />
        </View>

        {/* Modules */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.primary }]}>
            Revisión de obligaciones ({modulos.length})
          </Text>
          <Text style={[styles.hint, { color: colors.mutedForeground }]}>
            Activa el switch para aprobar cada módulo. Si rechazas, escribe una observación.
          </Text>
          {modulos.map((m, idx) => (
            <ModuleReviewRow
              key={m.obligacionId}
              modulo={m}
              index={idx}
              colors={colors}
              onToggle={(val) => toggleModulo(idx, val)}
              onObs={(val) => setObsModulo(idx, val)}
            />
          ))}
        </View>

        {/* General observation */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.primary }]}>Observación general</Text>
          <TextInput
            style={[styles.textarea, { backgroundColor: colors.background, borderColor: colors.border, color: colors.foreground }]}
            value={obsGeneral}
            onChangeText={setObsGeneral}
            placeholder="Observación general del formulario (opcional)"
            placeholderTextColor={colors.mutedForeground}
            multiline
            numberOfLines={4}
            textAlignVertical="top"
          />
        </View>
      </ScrollView>

      {/* Save button */}
      <View style={[styles.footer, { backgroundColor: colors.background, borderTopColor: colors.border, paddingBottom: bottomPad + 12 }]}>
        <Pressable
          onPress={handleSave}
          disabled={saving}
          style={({ pressed }) => [
            styles.saveBtn,
            { backgroundColor: colors.primary, opacity: pressed || saving ? 0.8 : 1 },
          ]}
        >
          {saving ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <>
              <Feather name="save" size={18} color="#fff" />
              <Text style={styles.saveBtnText}>Guardar verificación y notificar</Text>
            </>
          )}
        </Pressable>
      </View>
    </View>
  );
}

function InfoRow({ label, value, colors }: { label: string; value: string; colors: any }) {
  return (
    <View style={styles.infoRow}>
      <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.infoValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

function ModuleReviewRow({
  modulo,
  index,
  colors,
  onToggle,
  onObs,
}: {
  modulo: ModuloRevision;
  index: number;
  colors: any;
  onToggle: (val: boolean) => void;
  onObs: (val: string) => void;
}) {
  const isApproved = modulo.aprobado === true;
  const isRejected = modulo.aprobado === false;

  return (
    <View style={[styles.moduleCard, { borderColor: isApproved ? "#22c55e44" : isRejected ? "#ef444444" : colors.border }]}>
      <View style={styles.moduleTop}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.moduleNum, { color: colors.mutedForeground }]}>
            Obligación {index + 1}
          </Text>
          <Text style={[styles.moduleText, { color: colors.foreground }]} numberOfLines={3}>
            {modulo.obligacion}
          </Text>
        </View>
        <View style={styles.switchRow}>
          <Text style={[styles.switchLabel, { color: isApproved ? "#22c55e" : isRejected ? "#ef4444" : colors.mutedForeground }]}>
            {modulo.aprobado === null ? "Sin revisar" : isApproved ? "Aprobado" : "Rechazado"}
          </Text>
          <Switch
            value={isApproved}
            onValueChange={onToggle}
            trackColor={{ false: "#ef444480", true: "#22c55e80" }}
            thumbColor={isApproved ? "#22c55e" : "#ef4444"}
          />
        </View>
      </View>
      {isRejected && (
        <TextInput
          style={[styles.obsInput, { backgroundColor: colors.background, borderColor: "#ef444466", color: colors.foreground }]}
          value={modulo.observacion}
          onChangeText={onObs}
          placeholder="Observación (requerida al rechazar) *"
          placeholderTextColor="#ef444480"
          multiline
          numberOfLines={2}
          textAlignVertical="top"
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  header: {
    flexDirection: "row",
    alignItems: "flex-end",
    paddingHorizontal: 16,
    paddingBottom: 14,
    gap: 12,
  },
  headerName: { color: "#fff", fontFamily: "Inter_700Bold", fontSize: 16 },
  headerSub: { color: "rgba(255,255,255,0.75)", fontFamily: "Inter_400Regular", fontSize: 12 },
  body: { padding: 16, gap: 14 },
  section: { borderRadius: 14, borderWidth: 1, padding: 16, gap: 10 },
  sectionTitle: { fontFamily: "Inter_700Bold", fontSize: 15, marginBottom: 4 },
  hint: { fontFamily: "Inter_400Regular", fontSize: 12, marginBottom: 4 },
  infoRow: { flexDirection: "row", justifyContent: "space-between", gap: 12 },
  infoLabel: { fontFamily: "Inter_400Regular", fontSize: 13 },
  infoValue: { fontFamily: "Inter_500Medium", fontSize: 13, flexShrink: 1, textAlign: "right" },
  moduleCard: {
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    gap: 8,
  },
  moduleTop: { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  moduleNum: { fontFamily: "Inter_400Regular", fontSize: 11 },
  moduleText: { fontFamily: "Inter_500Medium", fontSize: 13, lineHeight: 18 },
  switchRow: { alignItems: "center", gap: 4 },
  switchLabel: { fontFamily: "Inter_500Medium", fontSize: 10 },
  obsInput: {
    borderWidth: 1,
    borderRadius: 8,
    padding: 10,
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    minHeight: 60,
  },
  textarea: {
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    minHeight: 80,
  },
  footer: {
    padding: 16,
    paddingTop: 12,
    borderTopWidth: 1,
  },
  saveBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingVertical: 15,
    borderRadius: 12,
  },
  saveBtnText: { color: "#fff", fontFamily: "Inter_700Bold", fontSize: 15 },
});
