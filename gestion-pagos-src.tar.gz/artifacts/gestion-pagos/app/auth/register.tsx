import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";

export default function RegisterScreen() {
  const { signUp } = useAuth();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [adminSecret, setAdminSecret] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [showAdminField, setShowAdminField] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleRegister = async () => {
    if (!name || !email || !password || !confirmPassword) {
      Alert.alert("Campos requeridos", "Por favor completa todos los campos.");
      return;
    }
    if (password.length < 6) {
      Alert.alert("Contraseña muy corta", "Debe tener al menos 6 caracteres.");
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert("Contraseñas distintas", "Las contraseñas no coinciden.");
      return;
    }

    setLoading(true);
    Platform.OS !== "web" && Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const error = await signUp(email.trim(), password, name.trim(), adminSecret || undefined);
    setLoading(false);

    if (error) {
      Alert.alert("Error al registrarse", translateError(error));
    } else {
      const isAdmin = adminSecret === process.env.EXPO_PUBLIC_ADMIN_SECRET && adminSecret !== "";
      Alert.alert(
        "¡Registro exitoso!",
        isAdmin
          ? "Cuenta de administrador creada. Inicia sesión para acceder al panel."
          : "Tu cuenta fue creada. Inicia sesión para comenzar.",
        [{ text: "OK", onPress: () => router.replace("/auth/login") }]
      );
    }
  };

  return (
    <KeyboardAvoidingView
      style={[styles.screen, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <ScrollView
        contentContainerStyle={[
          styles.container,
          { paddingTop: topPad + 20, paddingBottom: bottomPad + 40 },
        ]}
        keyboardShouldPersistTaps="handled"
      >
        {/* Back */}
        <Pressable onPress={() => router.back()} style={styles.backBtn} hitSlop={12}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </Pressable>

        {/* Header */}
        <View style={[styles.iconWrap, { backgroundColor: colors.primary + "18" }]}>
          <Feather name="user-plus" size={40} color={colors.primary} />
        </View>
        <Text style={[styles.title, { color: colors.foreground }]}>Crear cuenta</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Regístrate para gestionar tus pagos
        </Text>

        {/* Form */}
        <View style={styles.form}>
          <Field label="Nombre completo" icon="user" value={name} onChangeText={setName} autoCapitalize="words" colors={colors} />
          <Field label="Correo electrónico" icon="mail" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" colors={colors} />

          <View style={styles.fieldGap}>
            <Text style={[styles.label, { color: colors.foreground }]}>Contraseña</Text>
            <View style={[styles.inputWrap, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Feather name="lock" size={17} color={colors.mutedForeground} />
              <TextInput
                style={[styles.input, { color: colors.foreground }]}
                value={password}
                onChangeText={setPassword}
                placeholder="Mínimo 6 caracteres"
                placeholderTextColor={colors.mutedForeground}
                secureTextEntry={!showPass}
                autoCapitalize="none"
              />
              <Pressable onPress={() => setShowPass(!showPass)} hitSlop={10}>
                <Feather name={showPass ? "eye-off" : "eye"} size={17} color={colors.mutedForeground} />
              </Pressable>
            </View>
          </View>

          <Field label="Confirmar contraseña" icon="lock" value={confirmPassword} onChangeText={setConfirmPassword} secureTextEntry={!showPass} autoCapitalize="none" colors={colors} />

          {/* Admin secret toggle */}
          <Pressable
            onPress={() => setShowAdminField(!showAdminField)}
            style={styles.adminToggle}
          >
            <Feather name={showAdminField ? "chevron-up" : "chevron-down"} size={14} color={colors.mutedForeground} />
            <Text style={[styles.adminToggleText, { color: colors.mutedForeground }]}>
              ¿Registrarse como administrador?
            </Text>
          </Pressable>

          {showAdminField && (
            <View style={styles.fieldGap}>
              <Text style={[styles.label, { color: colors.foreground }]}>Código de administrador</Text>
              <View style={[styles.inputWrap, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Feather name="shield" size={17} color={colors.mutedForeground} />
                <TextInput
                  style={[styles.input, { color: colors.foreground }]}
                  value={adminSecret}
                  onChangeText={setAdminSecret}
                  placeholder="Código secreto"
                  placeholderTextColor={colors.mutedForeground}
                  secureTextEntry
                  autoCapitalize="none"
                />
              </View>
            </View>
          )}

          <Pressable
            onPress={handleRegister}
            disabled={loading}
            style={({ pressed }) => [
              styles.btn,
              { backgroundColor: colors.primary, opacity: pressed || loading ? 0.8 : 1 },
            ]}
          >
            {loading ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <>
                <Feather name="user-check" size={18} color="#fff" />
                <Text style={styles.btnText}>Crear Cuenta</Text>
              </>
            )}
          </Pressable>
        </View>

        <View style={styles.loginRow}>
          <Text style={[styles.loginText, { color: colors.mutedForeground }]}>¿Ya tienes cuenta?</Text>
          <Pressable onPress={() => router.replace("/auth/login")} hitSlop={8}>
            <Text style={[styles.loginLink, { color: colors.primary }]}> Inicia sesión</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function Field({ label, icon, value, onChangeText, placeholder, keyboardType, autoCapitalize, secureTextEntry, colors }: any) {
  return (
    <View style={styles.fieldGap}>
      <Text style={[styles.label, { color: colors.foreground }]}>{label}</Text>
      <View style={[styles.inputWrap, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Feather name={icon} size={17} color={colors.mutedForeground} />
        <TextInput
          style={[styles.input, { color: colors.foreground }]}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={colors.mutedForeground}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          secureTextEntry={secureTextEntry}
        />
      </View>
    </View>
  );
}

function translateError(msg: string): string {
  if (msg.includes("already registered")) return "Este correo ya está registrado.";
  if (msg.includes("invalid email")) return "El correo no es válido.";
  if (msg.includes("Password should be at least")) return "La contraseña debe tener al menos 6 caracteres.";
  return msg;
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  container: { paddingHorizontal: 28, alignItems: "center" },
  backBtn: { alignSelf: "flex-start", marginBottom: 16 },
  iconWrap: { width: 88, height: 88, borderRadius: 22, alignItems: "center", justifyContent: "center", marginBottom: 18 },
  title: { fontFamily: "Inter_700Bold", fontSize: 26, marginBottom: 6 },
  subtitle: { fontFamily: "Inter_400Regular", fontSize: 14, textAlign: "center", marginBottom: 28 },
  form: { width: "100%" },
  fieldGap: { marginBottom: 14 },
  label: { fontFamily: "Inter_500Medium", fontSize: 13, marginBottom: 6 },
  inputWrap: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, gap: 10, minHeight: 50 },
  input: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 15 },
  adminToggle: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 12, marginTop: 4 },
  adminToggleText: { fontFamily: "Inter_400Regular", fontSize: 13 },
  btn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, paddingVertical: 15, borderRadius: 12, marginTop: 20, minHeight: 52 },
  btnText: { color: "#fff", fontFamily: "Inter_700Bold", fontSize: 16 },
  loginRow: { flexDirection: "row", alignItems: "center", marginTop: 22 },
  loginText: { fontFamily: "Inter_400Regular", fontSize: 14 },
  loginLink: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
});
