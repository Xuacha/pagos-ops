import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/context/AuthContext";
import { getMySubmissions, Submission } from "@/lib/db";
import { useColors } from "@/hooks/useColors";
import { formatCurrency } from "@/utils/numberToWords";

const ESTADO_CONFIG = {
  pendiente:         { label: "Pendiente",  color: "#f59e0b", icon: "clock"        },
  aprobado:          { label: "Aprobado",   color: "#22c55e", icon: "check-circle" },
  rechazado_parcial: { label: "Rechazado",  color: "#ef4444", icon: "x-circle"     },
} as const;

function SubmissionCard({ item, onPress }: { item: Submission; onPress: () => void }) {
  const colors = useColors();
  const cfg = ESTADO_CONFIG[item.estado];
  const payment = item.payment_data;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.85 : 1 },
      ]}
    >
      <View style={styles.cardTop}>
        <View style={[styles.badge, { backgroundColor: colors.primary }]}>
          <Text style={[styles.badgeText, { color: "#fff" }]}>
            Acta #{payment.actaPagoNumero}
          </Text>
        </View>
        <View style={[styles.estadoBadge, { backgroundColor: cfg.color + "18", borderColor: cfg.color + "44" }]}>
          <Feather name={cfg.icon as any} size={12} color={cfg.color} />
          <Text style={[styles.estadoText, { color: cfg.color }]}>{cfg.label}</Text>
        </View>
        <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
      </View>

      <View style={styles.cardBody}>
        <View style={styles.infoRow}>
          <Feather name="calendar" size={12} color={colors.mutedForeground} />
          <Text style={[styles.infoText, { color: colors.mutedForeground }]}>
            {payment.periodoDesde} – {payment.periodoHasta}
          </Text>
        </View>
        <Text style={[styles.amount, { color: colors.primary }]}>
          {formatCurrency(payment.valorPagoNumeros)}
        </Text>
        <Text style={[styles.infoText, { color: colors.mutedForeground }]}>
          Enviado: {new Date(item.fecha_envio).toLocaleDateString("es-CO")}
        </Text>
        {item.fecha_revision && (
          <Text style={[styles.infoText, { color: colors.mutedForeground }]}>
            Revisado: {new Date(item.fecha_revision).toLocaleDateString("es-CO")}
          </Text>
        )}
        {item.observacion_general ? (
          <Text style={[styles.obs, { color: colors.mutedForeground }]} numberOfLines={2}>
            Obs: {item.observacion_general}
          </Text>
        ) : null}
      </View>
    </Pressable>
  );
}

export default function HistorialScreen() {
  const { user } = useAuth();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const data = await getMySubmissions(user.id);
    setSubmissions(data);
    setLoading(false);
  }, [user]);

  useEffect(() => { load(); }, [load]);

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.primary, paddingTop: (Platform.OS === "web" ? 20 : insets.top) + 12 }]}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Feather name="arrow-left" size={22} color="#fff" />
        </Pressable>
        <Text style={styles.headerTitle}>Historial de Envíos</Text>
        <Pressable onPress={load} hitSlop={12}>
          <Feather name="refresh-cw" size={18} color="rgba(255,255,255,0.8)" />
        </Pressable>
      </View>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      ) : (
        <FlatList
          data={submissions}
          keyExtractor={(s) => s.id}
          contentContainerStyle={[styles.list, { paddingBottom: bottomPad + 20 }]}
          renderItem={({ item }) => (
            <SubmissionCard
              item={item}
              onPress={() => router.push({ pathname: "/historial/[id]", params: { id: item.id } })}
            />
          )}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Feather name="inbox" size={40} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                Aún no has enviado formularios
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 14,
    gap: 12,
  },
  headerTitle: { flex: 1, color: "#fff", fontFamily: "Inter_700Bold", fontSize: 18 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  list: { padding: 16, gap: 12 },
  card: {
    borderRadius: 14,
    borderWidth: 1,
    overflow: "hidden",
    padding: 14,
  },
  cardTop: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10 },
  badge: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 6 },
  badgeText: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
  estadoBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    borderWidth: 1,
  },
  estadoText: { fontFamily: "Inter_600SemiBold", fontSize: 11 },
  cardBody: { gap: 3 },
  infoRow: { flexDirection: "row", alignItems: "center", gap: 4 },
  infoText: { fontFamily: "Inter_400Regular", fontSize: 12 },
  amount: { fontFamily: "Inter_700Bold", fontSize: 15, marginVertical: 2 },
  obs: { fontFamily: "Inter_400Regular", fontSize: 12, fontStyle: "italic", marginTop: 4 },
  empty: { alignItems: "center", marginTop: 80, gap: 12 },
  emptyText: { fontFamily: "Inter_400Regular", fontSize: 15 },
});
