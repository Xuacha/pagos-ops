import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { getSubmission, Submission, ModuloRevision } from "@/lib/db";
import { useColors } from "@/hooks/useColors";
import { formatCurrency } from "@/utils/numberToWords";
import { hapticLight } from "@/utils/platform";
import { printAndSharePdf } from "@/utils/pdfPlatform";
import { buildFutpHtml } from "@/utils/pdfGenerator";

const ESTADO_CONFIG = {
  pendiente:         { label: "Pendiente",  color: "#f59e0b" },
  aprobado:          { label: "Aprobado",   color: "#22c55e" },
  rechazado_parcial: { label: "Con observaciones", color: "#ef4444" },
} as const;

export default function HistorialDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const [sub, setSub] = useState<Submission | null>(null);
  const [loading, setLoading] = useState(true);
  const [pdfLoading, setPdfLoading] = useState(false);

  useEffect(() => {
    if (!id) return;
    getSubmission(id).then((s) => { setSub(s); setLoading(false); });
  }, [id]);

  const handlePdf = async () => {
    if (!sub) return;
    setPdfLoading(true);
    hapticLight();
    try {
      const html = buildFutpHtml(sub.profile_data, sub.payment_data, undefined, sub.modulos_revision);
      await printAndSharePdf(html, `FUTP_Acta${sub.payment_data.actaPagoNumero}.pdf`);
    } catch (e: any) {
      console.warn(e);
    } finally {
      setPdfLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <ActivityIndicator color={colors.primary} size="large" />
      </View>
    );
  }

  if (!sub) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.mutedForeground }}>Envío no encontrado</Text>
      </View>
    );
  }

  const cfg = ESTADO_CONFIG[sub.estado];
  const payment = sub.payment_data;

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.primary, paddingTop: (Platform.OS === "web" ? 20 : insets.top) + 12 }]}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Feather name="arrow-left" size={22} color="#fff" />
        </Pressable>
        <Text style={styles.headerTitle}>Acta #{payment.actaPagoNumero}</Text>
        <View style={[styles.estadoBadge, { backgroundColor: cfg.color + "33" }]}>
          <Text style={[styles.estadoText, { color: cfg.color }]}>{cfg.label}</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={[styles.body, { paddingBottom: bottomPad + 80 }]}>
        {/* Summary */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.primary }]}>Resumen del pago</Text>
          <Row label="Período" value={`${payment.periodoDesde} – ${payment.periodoHasta}`} colors={colors} />
          <Row label="Valor" value={formatCurrency(payment.valorPagoNumeros)} colors={colors} />
          <Row label="Enviado" value={new Date(sub.fecha_envio).toLocaleString("es-CO")} colors={colors} />
          {sub.fecha_revision && (
            <Row label="Revisado" value={new Date(sub.fecha_revision).toLocaleString("es-CO")} colors={colors} />
          )}
        </View>

        {/* Modules */}
        {sub.modulos_revision.length > 0 && (
          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.sectionTitle, { color: colors.primary }]}>Revisión por módulo</Text>
            {sub.modulos_revision.map((m, i) => (
              <ModuleRow key={m.obligacionId} modulo={m} index={i} colors={colors} />
            ))}
          </View>
        )}

        {/* General observation */}
        {sub.observacion_general ? (
          <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.sectionTitle, { color: colors.primary }]}>Observación general</Text>
            <Text style={[styles.obsText, { color: colors.foreground }]}>{sub.observacion_general}</Text>
          </View>
        ) : null}
      </ScrollView>

      {/* Actions */}
      <View style={[styles.actions, { backgroundColor: colors.background, borderTopColor: colors.border, paddingBottom: bottomPad + 12 }]}>
        <Pressable
          onPress={handlePdf}
          disabled={pdfLoading}
          style={({ pressed }) => [styles.pdfBtn, { backgroundColor: colors.primary, opacity: pressed || pdfLoading ? 0.8 : 1 }]}
        >
          {pdfLoading ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <>
              <Feather name="file-text" size={18} color="#fff" />
              <Text style={styles.pdfBtnText}>Ver PDF con observaciones</Text>
            </>
          )}
        </Pressable>
      </View>
    </View>
  );
}

function Row({ label, value, colors }: { label: string; value: string; colors: any }) {
  return (
    <View style={styles.row}>
      <Text style={[styles.rowLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.rowValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

function ModuleRow({ modulo, index, colors }: { modulo: ModuloRevision; index: number; colors: any }) {
  const iconName = modulo.aprobado === true ? "check-circle" : modulo.aprobado === false ? "x-circle" : "clock";
  const iconColor = modulo.aprobado === true ? "#22c55e" : modulo.aprobado === false ? "#ef4444" : "#f59e0b";

  return (
    <View style={[styles.moduleRow, { borderColor: colors.border }]}>
      <View style={styles.moduleTop}>
        <Feather name={iconName as any} size={16} color={iconColor} />
        <Text style={[styles.moduleText, { color: colors.foreground }]} numberOfLines={2}>
          {index + 1}. {modulo.obligacion}
        </Text>
      </View>
      {modulo.observacion ? (
        <Text style={[styles.moduleObs, { color: colors.mutedForeground }]}>
          Obs: {modulo.observacion}
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 14,
    gap: 12,
  },
  headerTitle: { flex: 1, color: "#fff", fontFamily: "Inter_700Bold", fontSize: 18 },
  estadoBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  estadoText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  body: { padding: 16, gap: 14 },
  section: { borderRadius: 14, borderWidth: 1, padding: 16, gap: 10 },
  sectionTitle: { fontFamily: "Inter_700Bold", fontSize: 15, marginBottom: 4 },
  row: { flexDirection: "row", justifyContent: "space-between", gap: 12 },
  rowLabel: { fontFamily: "Inter_400Regular", fontSize: 13 },
  rowValue: { fontFamily: "Inter_500Medium", fontSize: 13, flexShrink: 1, textAlign: "right" },
  obsText: { fontFamily: "Inter_400Regular", fontSize: 13, lineHeight: 20 },
  moduleRow: { borderTopWidth: 1, paddingTop: 10, gap: 4 },
  moduleTop: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  moduleText: { fontFamily: "Inter_500Medium", fontSize: 13, flex: 1 },
  moduleObs: { fontFamily: "Inter_400Regular", fontSize: 12, fontStyle: "italic", paddingLeft: 24 },
  actions: {
    padding: 16,
    paddingTop: 12,
    borderTopWidth: 1,
  },
  pdfBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingVertical: 15,
    borderRadius: 12,
  },
  pdfBtnText: { color: "#fff", fontFamily: "Inter_700Bold", fontSize: 15 },
});
