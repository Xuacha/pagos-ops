import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp, Payment } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import { NotificationBell } from "@/components/NotificationBell";
import {
  createSubmission,
  createNotification,
  getAllAdmins,
} from "@/lib/db";
import { useColors } from "@/hooks/useColors";
import { formatCurrency } from "@/utils/numberToWords";

function PaymentCard({ payment, onPress }: { payment: Payment; onPress: () => void }) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          opacity: pressed ? 0.85 : 1,
        },
      ]}
    >
      <View style={styles.cardHeader}>
        <View style={[styles.badge, { backgroundColor: colors.primary }]}>
          <Text style={[styles.badgeText, { color: colors.primaryForeground }]}>
            Acta #{payment.actaPagoNumero}
          </Text>
        </View>
        {payment.tieneAdicion && (
          <View style={[styles.badge, { backgroundColor: colors.gold }]}>
            <Text style={[styles.badgeText, { color: "#fff" }]}>ADICIÓN</Text>
          </View>
        )}
        <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
      </View>
      <View style={styles.cardBody}>
        <View style={styles.infoRow}>
          <Feather name="calendar" size={13} color={colors.mutedForeground} />
          <Text style={[styles.infoText, { color: colors.mutedForeground }]}>
            {payment.periodoDesde} – {payment.periodoHasta}
          </Text>
        </View>
        <Text style={[styles.amount, { color: colors.primary }]}>
          {formatCurrency(payment.valorPagoNumeros)}
        </Text>
        <Text style={[styles.infoText, { color: colors.mutedForeground }]}>
          {payment.fechaCreacion}
        </Text>
      </View>
    </Pressable>
  );
}

export default function HomeScreen() {
  const { profile, payments, isLoading } = useApp();
  const { signOut, user } = useAuth();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [submitting, setSubmitting] = useState<string | null>(null);

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const myPayments = payments.filter((p) => p.profileId === profile?.id);

  const handleNewPayment = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push("/payment/new");
  };

  const handleSubmitToAdmin = async (payment: Payment) => {
    if (!profile || !user) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Alert.alert(
      "Enviar a administrador",
      `¿Deseas enviar el Acta #${payment.actaPagoNumero} al administrador para revisión?`,
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Enviar",
          onPress: async () => {
            setSubmitting(payment.id);
            const subId = await createSubmission(user.id, profile.nombreContratista, profile, payment);
            if (subId) {
              const admins = await getAllAdmins();
              await Promise.all(
                admins.map((a) =>
                  createNotification(
                    a.id,
                    "📄 Nuevo formulario enviado",
                    `${profile.nombreContratista} envió el Acta #${payment.actaPagoNumero} (${payment.periodoDesde} – ${payment.periodoHasta}).`,
                    "nuevo_envio"
                  )
                )
              );
              Alert.alert("✅ Enviado", "El formulario fue enviado al administrador. Revisa el historial para ver su estado.");
            } else {
              Alert.alert("Error", "No se pudo enviar. Verifica tu conexión e intenta de nuevo.");
            }
            setSubmitting(null);
          },
        },
      ]
    );
  };

  if (isLoading) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.mutedForeground }}>Cargando...</Text>
      </View>
    );
  }

  if (!profile) {
    return (
      <View
        style={[
          styles.onboarding,
          {
            backgroundColor: colors.background,
            paddingTop: topPad + 20,
            paddingBottom: bottomPad + 20,
          },
        ]}
      >
        <View style={[styles.onboardingIcon, { backgroundColor: colors.primary + "18" }]}>
          <Feather name="file-text" size={48} color={colors.primary} />
        </View>
        <Text style={[styles.onboardingTitle, { color: colors.foreground }]}>
          Gestión de Pagos
        </Text>
        <Text style={[styles.onboardingTitle2, { color: colors.mutedForeground }]}>
          FUTP - Formato Único de{"\n"}Trámite de Pago
        </Text>
        <Text style={[styles.onboardingDesc, { color: colors.mutedForeground }]}>
          Registra tu perfil de contratista y genera los documentos de cobro
          fiel al formato oficial de la alcaldía.
        </Text>
        <Pressable
          onPress={() => router.push("/profile/setup")}
          style={({ pressed }) => [
            styles.primaryButton,
            { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
          ]}
        >
          <Feather name="user-plus" size={18} color="#fff" />
          <Text style={styles.primaryButtonText}>Crear Perfil</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View
        style={[
          styles.header,
          {
            backgroundColor: colors.primary,
            paddingTop: topPad + 12,
          },
        ]}
      >
        {profile.logoUri ? (
          <Image source={{ uri: profile.logoUri }} style={styles.logo} />
        ) : (
          <View style={[styles.logoPlaceholder, { backgroundColor: "rgba(255,255,255,0.2)" }]}>
            <Feather name="image" size={18} color="rgba(255,255,255,0.7)" />
          </View>
        )}
        <View style={styles.headerInfo}>
          <Text style={styles.headerName} numberOfLines={1}>
            {profile.nombreContratista}
          </Text>
          <Text style={styles.headerSub} numberOfLines={1}>
            {profile.secretaria}
          </Text>
          <Text style={styles.headerSub}>Contrato: {profile.numeroContrato}</Text>
        </View>
        <View style={{ flexDirection: "row", gap: 16, alignItems: "center" }}>
          <NotificationBell />
          <Pressable onPress={() => router.push("/historial")} hitSlop={12}>
            <Feather name="clock" size={18} color="rgba(255,255,255,0.85)" />
          </Pressable>
          <Pressable onPress={() => router.push("/profile/edit")} hitSlop={12}>
            <Feather name="edit-2" size={18} color="rgba(255,255,255,0.85)" />
          </Pressable>
          <Pressable onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); signOut(); }} hitSlop={12}>
            <Feather name="log-out" size={18} color="rgba(255,255,255,0.85)" />
          </Pressable>
        </View>
      </View>

      {/* Summary bar */}
      <View style={[styles.summaryBar, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.summaryItem}>
          <Text style={[styles.summaryNum, { color: colors.primary }]}>
            {myPayments.length}
          </Text>
          <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Pagos</Text>
        </View>
        <View style={[styles.summaryDivider, { backgroundColor: colors.border }]} />
        <View style={styles.summaryItem}>
          <Text style={[styles.summaryNum, { color: colors.primary }]}>
            {formatCurrency(myPayments.reduce((a, p) => a + p.valorPagoNumeros, 0)).replace("COP", "").trim()}
          </Text>
          <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Total ejecutado</Text>
        </View>
        <View style={[styles.summaryDivider, { backgroundColor: colors.border }]} />
        <View style={styles.summaryItem}>
          <Text style={[styles.summaryNum, { color: colors.gold }]}>
            {myPayments.filter((p) => p.tieneAdicion).length}
          </Text>
          <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Adiciones</Text>
        </View>
      </View>

      {/* List */}
      <FlatList
        data={myPayments.sort((a, b) => b.actaPagoNumero - a.actaPagoNumero)}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.listContent,
          { paddingBottom: bottomPad + 100 },
        ]}
        renderItem={({ item }) => (
          <View>
            <PaymentCard
              payment={item}
              onPress={() => router.push(`/payment/${item.id}`)}
            />
            <Pressable
              onPress={() => handleSubmitToAdmin(item)}
              disabled={submitting === item.id}
              style={({ pressed }) => [
                styles.submitBtn,
                { backgroundColor: colors.primary + "18", borderColor: colors.primary + "33", opacity: pressed ? 0.7 : 1 },
              ]}
            >
              {submitting === item.id ? (
                <ActivityIndicator size="small" color={colors.primary} />
              ) : (
                <>
                  <Feather name="send" size={14} color={colors.primary} />
                  <Text style={[styles.submitBtnText, { color: colors.primary }]}>Enviar a administrador</Text>
                </>
              )}
            </Pressable>
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="inbox" size={36} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              No hay pagos registrados
            </Text>
          </View>
        }
      />

      {/* FAB */}
      <Pressable
        onPress={handleNewPayment}
        style={({ pressed }) => [
          styles.fab,
          {
            backgroundColor: colors.primary,
            bottom: bottomPad + 24,
            opacity: pressed ? 0.85 : 1,
          },
        ]}
      >
        <Feather name="plus" size={26} color="#fff" />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 18,
    paddingBottom: 16,
    gap: 12,
  },
  logo: { width: 40, height: 40, borderRadius: 8, backgroundColor: "#fff" },
  logoPlaceholder: {
    width: 40,
    height: 40,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  headerInfo: { flex: 1 },
  headerName: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 15,
  },
  headerSub: {
    color: "rgba(255,255,255,0.8)",
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginTop: 1,
  },
  summaryBar: {
    flexDirection: "row",
    borderBottomWidth: 1,
    paddingVertical: 12,
  },
  summaryItem: { flex: 1, alignItems: "center" },
  summaryNum: {
    fontFamily: "Inter_700Bold",
    fontSize: 18,
  },
  summaryLabel: {
    fontFamily: "Inter_400Regular",
    fontSize: 11,
    marginTop: 2,
  },
  summaryDivider: { width: 1, marginVertical: 4 },
  listContent: { padding: 16, gap: 12 },
  card: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    gap: 8,
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  badgeText: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 11,
  },
  cardBody: { gap: 4 },
  infoRow: { flexDirection: "row", alignItems: "center", gap: 5 },
  infoText: { fontFamily: "Inter_400Regular", fontSize: 12 },
  amount: { fontFamily: "Inter_700Bold", fontSize: 18, marginTop: 2 },
  fab: {
    position: "absolute",
    right: 20,
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
  },
  onboarding: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
    gap: 16,
  },
  onboardingIcon: {
    width: 100,
    height: 100,
    borderRadius: 24,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  onboardingTitle: {
    fontFamily: "Inter_700Bold",
    fontSize: 26,
    textAlign: "center",
  },
  onboardingTitle2: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 16,
    textAlign: "center",
  },
  onboardingDesc: {
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    textAlign: "center",
    lineHeight: 22,
  },
  primaryButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 28,
    paddingVertical: 14,
    borderRadius: 12,
    marginTop: 8,
  },
  primaryButtonText: {
    color: "#fff",
    fontFamily: "Inter_600SemiBold",
    fontSize: 16,
  },
  empty: {
    alignItems: "center",
    paddingTop: 60,
    gap: 12,
  },
  emptyText: {
    fontFamily: "Inter_400Regular",
    fontSize: 15,
  },
  submitBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 9,
    marginHorizontal: 16,
    marginTop: -8,
    marginBottom: 8,
    borderRadius: 8,
    borderWidth: 1,
    minHeight: 36,
  },
  submitBtnText: {
    fontFamily: "Inter_500Medium",
    fontSize: 13,
  },
});
