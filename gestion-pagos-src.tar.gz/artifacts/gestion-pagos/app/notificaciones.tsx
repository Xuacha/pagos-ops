import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useEffect } from "react";
import {
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useNotifications } from "@/context/NotificationContext";
import { useColors } from "@/hooks/useColors";
import { DBNotification } from "@/lib/db";

const TYPE_ICON: Record<string, string> = {
  aprobado: "check-circle",
  rechazado: "x-circle",
  nuevo_envio: "send",
  info: "info",
};

const TYPE_COLOR: Record<string, string> = {
  aprobado: "#22c55e",
  rechazado: "#ef4444",
  nuevo_envio: "#3b82f6",
  info: "#6b7280",
};

function NotifCard({
  item,
  onPress,
}: {
  item: DBNotification;
  onPress: () => void;
}) {
  const colors = useColors();
  const icon = TYPE_ICON[item.tipo] ?? "info";
  const iconColor = TYPE_COLOR[item.tipo] ?? colors.mutedForeground;

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: item.leido ? colors.card : colors.primary + "0d",
          borderColor: item.leido ? colors.border : colors.primary + "33",
          opacity: pressed ? 0.8 : 1,
        },
      ]}
    >
      <View style={[styles.iconWrap, { backgroundColor: iconColor + "18" }]}>
        <Feather name={icon as any} size={20} color={iconColor} />
      </View>
      <View style={styles.content}>
        <Text
          style={[
            styles.titulo,
            {
              color: colors.foreground,
              fontFamily: item.leido ? "Inter_400Regular" : "Inter_700Bold",
            },
          ]}
        >
          {item.titulo}
        </Text>
        <Text
          style={[styles.mensaje, { color: colors.mutedForeground }]}
          numberOfLines={2}
        >
          {item.mensaje}
        </Text>
        <Text style={[styles.fecha, { color: colors.mutedForeground }]}>
          {new Date(item.fecha).toLocaleString("es-CO")}
        </Text>
      </View>
      {!item.leido && (
        <View style={[styles.dot, { backgroundColor: colors.primary }]} />
      )}
    </Pressable>
  );
}

export default function NotificacionesScreen() {
  const { notifications, markRead, markAllAsRead, refresh } = useNotifications();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  useEffect(() => { refresh(); }, []);

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.primary, paddingTop: (Platform.OS === "web" ? 20 : insets.top) + 12 }]}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Feather name="arrow-left" size={22} color="#fff" />
        </Pressable>
        <Text style={styles.headerTitle}>Notificaciones</Text>
        <Pressable onPress={markAllAsRead} hitSlop={12}>
          <Text style={styles.markAll}>Leer todas</Text>
        </Pressable>
      </View>

      <FlatList
        data={notifications}
        keyExtractor={(n) => n.id}
        contentContainerStyle={[styles.list, { paddingBottom: bottomPad + 20 }]}
        renderItem={({ item }) => (
          <NotifCard item={item} onPress={() => markRead(item.id)} />
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="bell-off" size={40} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              No hay notificaciones
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 14,
    gap: 12,
  },
  headerTitle: {
    flex: 1,
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 18,
  },
  markAll: {
    color: "rgba(255,255,255,0.8)",
    fontFamily: "Inter_400Regular",
    fontSize: 12,
  },
  list: { padding: 16, gap: 10 },
  card: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  content: { flex: 1 },
  titulo: { fontSize: 14, marginBottom: 2 },
  mensaje: { fontFamily: "Inter_400Regular", fontSize: 13, lineHeight: 18, marginBottom: 4 },
  fecha: { fontFamily: "Inter_400Regular", fontSize: 11 },
  dot: { width: 8, height: 8, borderRadius: 4, marginTop: 4 },
  empty: { alignItems: "center", marginTop: 80, gap: 12 },
  emptyText: { fontFamily: "Inter_400Regular", fontSize: 15 },
});
