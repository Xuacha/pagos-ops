import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import * as Haptics from "expo-haptics";
import React from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { formatCurrency } from "@/utils/numberToWords";

function InfoRow({ label, value }: { label: string; value: string | number }) {
  const colors = useColors();
  return (
    <View style={[styles.infoRow, { borderColor: colors.border }]}>
      <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.infoValue, { color: colors.foreground }]}>
        {String(value)}
      </Text>
    </View>
  );
}

function SectionHeader({ title }: { title: string }) {
  const colors = useColors();
  return (
    <View style={[styles.sectionHeader, { backgroundColor: colors.primary }]}>
      <Text style={styles.sectionHeaderText}>{title}</Text>
    </View>
  );
}

export default function PaymentDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { profile, payments, deletePayment } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const payment = payments.find((p) => p.id === id);

  if (!payment || !profile) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.mutedForeground }}>Pago no encontrado</Text>
      </View>
    );
  }

  const handleDelete = () => {
    Alert.alert(
      "Eliminar Pago",
      "¿Estás seguro que deseas eliminar este pago?",
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Eliminar",
          style: "destructive",
          onPress: async () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
            await deletePayment(id);
            router.replace("/");
          },
        },
      ]
    );
  };

  const valorInicialMasAdiciones = payment.valorInicial + payment.valorAdiciones;
  const saldo = valorInicialMasAdiciones - payment.valorPagoNumeros;
  const porcentaje =
    valorInicialMasAdiciones > 0
      ? ((payment.valorPagoNumeros / valorInicialMasAdiciones) * 100).toFixed(2)
      : "0.00";

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: bottomPad + 120 }]}>
        {/* Header card */}
        <View style={[styles.headerCard, { backgroundColor: colors.primary }]}>
          <View style={styles.headerRow}>
            <View style={[styles.actaBadge, { backgroundColor: "rgba(255,255,255,0.2)" }]}>
              <Text style={styles.actaText}>Acta #{payment.actaPagoNumero}</Text>
            </View>
            {payment.tieneAdicion && (
              <View style={[styles.actaBadge, { backgroundColor: colors.gold }]}>
                <Text style={styles.actaText}>ADICIÓN</Text>
              </View>
            )}
          </View>
          <Text style={styles.amount}>{formatCurrency(payment.valorPagoNumeros)}</Text>
          <Text style={styles.period}>
            {payment.periodoDesde} – {payment.periodoHasta}
          </Text>
          <Text style={styles.letras} numberOfLines={2}>
            {payment.valorPagoLetras}
          </Text>
        </View>

        {/* Datos básicos */}
        <SectionHeader title="DATOS DEL PAGO" />
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <InfoRow label="Contratista" value={profile.nombreContratista} />
          <InfoRow label="No. Contrato" value={profile.numeroContrato} />
          <InfoRow label="Secretaría" value={profile.secretaria} />
          <InfoRow label="Período pago" value={payment.periodoPagoSeguridad} />
          <InfoRow label="No. Planilla" value={payment.noPlanilla} />
          <InfoRow label="Fecha creación" value={payment.fechaCreacion} />
        </View>

        {/* Balance */}
        <SectionHeader title="IV. BALANCE FINANCIERO" />
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <InfoRow label="Valor Inicial" value={formatCurrency(payment.valorInicial)} />
          <InfoRow label="Valor Adiciones" value={formatCurrency(payment.valorAdiciones)} />
          <InfoRow label="Valor Total" value={formatCurrency(valorInicialMasAdiciones)} />
          <InfoRow label="Valor Ejecutado" value={formatCurrency(payment.valorPagoNumeros)} />
          <InfoRow label="% Ejecución" value={`${porcentaje}%`} />
          <InfoRow label="Saldo por Ejecutar" value={formatCurrency(saldo)} />
        </View>

        {/* Adición */}
        {payment.tieneAdicion && (
          <>
            <SectionHeader title="DATOS DE ADICIÓN" />
            <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <InfoRow label="Valor Adición" value={formatCurrency(payment.adicionValor ?? 0)} />
              <InfoRow label="Plazo Adición" value={payment.adicionPlazo ?? ""} />
              <InfoRow label="Fecha Inicio" value={payment.adicionFechaInicio ?? ""} />
              <InfoRow label="Fecha Fin" value={payment.adicionFechaFin ?? ""} />
            </View>
          </>
        )}

        {/* Obligaciones */}
        <SectionHeader title="II. ACTIVIDADES DEL PERÍODO" />
        {(profile.obligacionesContractuales ?? []).map((ob, idx) => {
          const det = payment.obligacionesDetalle.find((d) => d.obligacionId === ob.id);
          return (
            <View
              key={ob.id}
              style={[styles.obligacionCard, { borderColor: colors.border, backgroundColor: colors.card }]}
            >
              <View style={[styles.obligacionHeader, { backgroundColor: colors.primary + "12" }]}>
                <Text style={[styles.obligacionNum, { color: colors.primary }]}>{idx + 1}</Text>
                <Text style={[styles.obligacionText, { color: colors.foreground }]} numberOfLines={3}>
                  {ob.obligacion}
                </Text>
              </View>
              <View style={styles.obligacionBody}>
                <Text style={[styles.label, { color: colors.mutedForeground }]}>Actividad:</Text>
                <Text style={[styles.value, { color: colors.foreground }]}>{det?.actividad || "-"}</Text>
                <Text style={[styles.label, { color: colors.mutedForeground, marginTop: 8 }]}>Evidencia:</Text>
                <Text style={[styles.value, { color: colors.foreground }]}>{det?.evidencia || "-"}</Text>
              </View>
            </View>
          );
        })}
      </ScrollView>

      {/* Action buttons */}
      <View
        style={[
          styles.actions,
          {
            backgroundColor: colors.background,
            borderTopColor: colors.border,
            paddingBottom: bottomPad + 12,
          },
        ]}
      >
        <Pressable
          onPress={handleDelete}
          style={({ pressed }) => [
            styles.deleteBtn,
            { borderColor: colors.destructive, opacity: pressed ? 0.7 : 1 },
          ]}
        >
          <Feather name="trash-2" size={18} color={colors.destructive} />
        </Pressable>

        <Pressable
          onPress={() =>
            router.push({
              pathname: "/payment/preview",
              params: { id: payment.id, type: "futp" },
            })
          }
          style={({ pressed }) => [
            styles.previewBtn,
            { backgroundColor: colors.secondary, flex: 1, opacity: pressed ? 0.85 : 1 },
          ]}
        >
          <Feather name="file" size={16} color={colors.primary} />
          <Text style={[styles.previewBtnText, { color: colors.primary }]}>FUTP</Text>
        </Pressable>

        <Pressable
          onPress={() =>
            router.push({
              pathname: "/payment/preview",
              params: { id: payment.id, type: "retefuente" },
            })
          }
          style={({ pressed }) => [
            styles.previewBtn,
            { backgroundColor: colors.secondary, flex: 1, opacity: pressed ? 0.85 : 1 },
          ]}
        >
          <Feather name="percent" size={16} color={colors.primary} />
          <Text style={[styles.previewBtnText, { color: colors.primary }]}>RETE</Text>
        </Pressable>

        {payment.tieneAdicion && (
          <Pressable
            onPress={() =>
              router.push({
                pathname: "/payment/preview",
                params: { id: payment.id, type: "adicion" },
              })
            }
            style={({ pressed }) => [
              styles.previewBtn,
              { backgroundColor: colors.gold, flex: 1, opacity: pressed ? 0.85 : 1 },
            ]}
          >
            <Feather name="plus-square" size={16} color="#fff" />
            <Text style={[styles.previewBtnText, { color: "#fff" }]}>ADICIÓN</Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  content: { padding: 16, gap: 0 },
  headerCard: {
    borderRadius: 14,
    padding: 18,
    marginBottom: 12,
    gap: 6,
  },
  headerRow: { flexDirection: "row", gap: 8, marginBottom: 4 },
  actaBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  actaText: { fontFamily: "Inter_600SemiBold", fontSize: 12, color: "#fff" },
  amount: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 28,
    marginTop: 4,
  },
  period: {
    color: "rgba(255,255,255,0.85)",
    fontFamily: "Inter_500Medium",
    fontSize: 13,
  },
  letras: {
    color: "rgba(255,255,255,0.7)",
    fontFamily: "Inter_400Regular",
    fontSize: 11,
    marginTop: 2,
  },
  sectionHeader: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    marginBottom: 8,
    marginTop: 12,
  },
  sectionHeaderText: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 11,
    letterSpacing: 0.5,
  },
  card: {
    borderRadius: 12,
    borderWidth: 1,
    overflow: "hidden",
    marginBottom: 4,
  },
  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderBottomWidth: 1,
    gap: 8,
  },
  infoLabel: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    flex: 1,
  },
  infoValue: {
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    flex: 2,
    textAlign: "right",
  },
  obligacionCard: {
    borderWidth: 1,
    borderRadius: 10,
    marginBottom: 8,
    overflow: "hidden",
  },
  obligacionHeader: {
    flexDirection: "row",
    gap: 10,
    padding: 10,
    alignItems: "flex-start",
  },
  obligacionNum: {
    fontFamily: "Inter_700Bold",
    fontSize: 14,
    minWidth: 20,
  },
  obligacionText: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    flex: 1,
    lineHeight: 18,
  },
  obligacionBody: { padding: 12, gap: 2 },
  label: { fontFamily: "Inter_500Medium", fontSize: 11 },
  value: { fontFamily: "Inter_400Regular", fontSize: 12, lineHeight: 18 },
  actions: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    gap: 8,
    paddingHorizontal: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    elevation: 4,
  },
  deleteBtn: {
    width: 46,
    height: 46,
    borderRadius: 10,
    borderWidth: 1.5,
    alignItems: "center",
    justifyContent: "center",
  },
  previewBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 12,
    borderRadius: 10,
  },
  previewBtnText: {
    fontFamily: "Inter_700Bold",
    fontSize: 12,
  },
});
