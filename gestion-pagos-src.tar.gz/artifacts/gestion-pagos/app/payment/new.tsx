import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { FormField } from "@/components/FormField";
import { useApp, Payment, ObligacionDetalle } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { numberToWords } from "@/utils/numberToWords";

function SectionHeader({ title }: { title: string }) {
  const colors = useColors();
  return (
    <View style={[styles.sectionHeader, { backgroundColor: colors.sectionHeader }]}>
      <Text style={styles.sectionHeaderText}>{title}</Text>
    </View>
  );
}

export default function NewPaymentScreen() {
  const { profile, payments, savePayment } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const nextActa = Math.max(0, ...payments.map((p) => p.actaPagoNumero)) + 1;

  const [valorPago, setValorPago] = useState("");
  const [periodoDesde, setPeriodoDesde] = useState("");
  const [periodoHasta, setPeriodoHasta] = useState("");
  const [periodoPago, setPeriodoPago] = useState("");
  const [noPlanilla, setNoPlanilla] = useState("");
  const [valorInicial, setValorInicial] = useState(
    String(profile?.valorTotalContrato ?? "")
  );
  const [valorAdiciones, setValorAdiciones] = useState("0");
  const [anticipo1, setAnticipo1] = useState("0");
  const [anticipo2, setAnticipo2] = useState("0");
  const [amortizaciones, setAmortizaciones] = useState("0");
  const [tieneAdicion, setTieneAdicion] = useState(false);
  const [adicionValor, setAdicionValor] = useState("");
  const [adicionPlazo, setAdicionPlazo] = useState("");
  const [adicionFechaInicio, setAdicionFechaInicio] = useState("");
  const [adicionFechaFin, setAdicionFechaFin] = useState("");

  const [obligacionesDetalle, setObligacionesDetalle] = useState<ObligacionDetalle[]>(
    (profile?.obligacionesContractuales ?? []).map((ob) => ({
      id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
      obligacionId: ob.id,
      actividad: ob.actividad,
      evidencia: ob.evidencia,
    }))
  );

  const updateDetalle = (obligacionId: string, field: keyof ObligacionDetalle, val: string) => {
    setObligacionesDetalle((prev) =>
      prev.map((d) => (d.obligacionId === obligacionId ? { ...d, [field]: val } : d))
    );
  };

  const handleSave = async () => {
    if (!profile) return;
    if (!valorPago || !periodoDesde || !periodoHasta) {
      Alert.alert("Campos requeridos", "Completa el valor del pago y el período.");
      return;
    }
    const valorNum = parseFloat(valorPago.replace(/[.,]/g, "")) || 0;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    const payment: Payment = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      profileId: profile.id,
      actaPagoNumero: nextActa,
      periodoDesde,
      periodoHasta,
      valorPagoNumeros: valorNum,
      valorPagoLetras: numberToWords(valorNum),
      periodoPagoSeguridad: periodoPago,
      noPlanilla,
      fechaCreacion: new Date().toLocaleDateString("es-CO"),
      obligacionesDetalle,
      tieneAdicion,
      adicionValor: parseFloat(adicionValor) || 0,
      adicionPlazo,
      adicionFechaInicio,
      adicionFechaFin,
      valorInicial: parseFloat(valorInicial.replace(/[.,]/g, "")) || 0,
      valorAdiciones: parseFloat(valorAdiciones.replace(/[.,]/g, "")) || 0,
      anticipos: {
        anticipo1: parseFloat(anticipo1) || 0,
        anticipo2: parseFloat(anticipo2) || 0,
      },
      amortizaciones: parseFloat(amortizaciones) || 0,
    };

    await savePayment(payment);
    router.replace(`/payment/${payment.id}`);
  };

  if (!profile) return null;

  return (
    <KeyboardAwareScrollView
      style={{ backgroundColor: colors.background }}
      contentContainerStyle={[styles.container, { paddingBottom: insets.bottom + 40 }]}
      keyboardShouldPersistTaps="handled"
      bottomOffset={20}
    >
      {/* Acta info */}
      <View style={[styles.actaBadge, { backgroundColor: colors.primary + "18", borderColor: colors.primary }]}>
        <Feather name="file-text" size={18} color={colors.primary} />
        <Text style={[styles.actaText, { color: colors.primary }]}>
          Acta de Pago No. {nextActa}
        </Text>
      </View>

      {/* Período */}
      <SectionHeader title="PERÍODO CERTIFICADO" />
      <View style={styles.row}>
        <View style={{ flex: 1 }}>
          <FormField
            label="Desde"
            required
            value={periodoDesde}
            onChangeText={setPeriodoDesde}
            placeholder="DD/MM/AAAA"
          />
        </View>
        <View style={{ flex: 1 }}>
          <FormField
            label="Hasta"
            required
            value={periodoHasta}
            onChangeText={setPeriodoHasta}
            placeholder="DD/MM/AAAA"
          />
        </View>
      </View>

      {/* Valor del pago */}
      <SectionHeader title="VALOR DEL PAGO" />
      <FormField
        label="Valor del pago en números ($)"
        required
        value={valorPago}
        onChangeText={setValorPago}
        placeholder="2544000"
        keyboardType="number-pad"
        hint={valorPago ? `En letras: ${numberToWords(parseFloat(valorPago.replace(/[.,]/g, "")) || 0)}` : undefined}
      />

      {/* Balance financiero */}
      <SectionHeader title="IV. BALANCE FINANCIERO" />
      <FormField
        label="Valor Inicial del Contrato ($)"
        value={valorInicial}
        onChangeText={setValorInicial}
        keyboardType="number-pad"
      />
      <FormField
        label="Valor Adiciones ($)"
        value={valorAdiciones}
        onChangeText={setValorAdiciones}
        keyboardType="number-pad"
      />
      <FormField
        label="Anticipo 1 ($)"
        value={anticipo1}
        onChangeText={setAnticipo1}
        keyboardType="number-pad"
      />
      <FormField
        label="Anticipo 2 ($)"
        value={anticipo2}
        onChangeText={setAnticipo2}
        keyboardType="number-pad"
      />
      <FormField
        label="Amortizaciones ($)"
        value={amortizaciones}
        onChangeText={setAmortizaciones}
        keyboardType="number-pad"
      />

      {/* Seguridad Social */}
      <SectionHeader title="III. SEGURIDAD SOCIAL" />
      <FormField
        label="Período de pago"
        value={periodoPago}
        onChangeText={setPeriodoPago}
        placeholder="enero / febrero / etc."
      />
      <FormField
        label="No. Planilla"
        value={noPlanilla}
        onChangeText={setNoPlanilla}
        placeholder="Número de planilla"
        keyboardType="number-pad"
      />

      {/* Obligaciones */}
      <SectionHeader title="II. ACTIVIDADES DEL PERÍODO" />
      <Text style={[styles.hint, { color: colors.mutedForeground }]}>
        Detalla las actividades realizadas y la evidencia para este período.
      </Text>
      {(profile.obligacionesContractuales ?? []).map((ob, idx) => {
        const det = obligacionesDetalle.find((d) => d.obligacionId === ob.id);
        return (
          <View
            key={ob.id}
            style={[styles.obligacionCard, { borderColor: colors.border, backgroundColor: colors.card }]}
          >
            <View style={[styles.obligacionHeader, { backgroundColor: colors.primary + "12" }]}>
              <Text style={[styles.obligacionNum, { color: colors.primary }]}>{idx + 1}</Text>
              <Text style={[styles.obligacionTitle, { color: colors.foreground }]} numberOfLines={2}>
                {ob.obligacion || "Obligación sin texto"}
              </Text>
            </View>
            <FormField
              label="Actividad realizada en el período"
              value={det?.actividad ?? ""}
              onChangeText={(t) => updateDetalle(ob.id, "actividad", t)}
              placeholder="Descripción cuantitativa y cualitativa"
              multiline
              numberOfLines={3}
              style={{ minHeight: 70, textAlignVertical: "top" }}
            />
            <FormField
              label="Evidencia verificable"
              value={det?.evidencia ?? ""}
              onChangeText={(t) => updateDetalle(ob.id, "evidencia", t)}
              placeholder="Referir la ubicación de los soportes"
              multiline
              numberOfLines={2}
              style={{ minHeight: 50, textAlignVertical: "top" }}
            />
          </View>
        );
      })}

      {/* Adición */}
      <SectionHeader title="ADICIÓN AL CONTRATO (OPCIONAL)" />
      <View style={styles.switchRow}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.label, { color: colors.foreground }]}>
            Este pago incluye adición
          </Text>
          <Text style={[styles.hint, { color: colors.mutedForeground }]}>
            Posterior a la fecha de terminación
          </Text>
        </View>
        <Switch
          value={tieneAdicion}
          onValueChange={setTieneAdicion}
          trackColor={{ true: colors.gold }}
        />
      </View>
      {tieneAdicion && (
        <View>
          <FormField
            label="Valor de la Adición ($)"
            value={adicionValor}
            onChangeText={setAdicionValor}
            keyboardType="number-pad"
            placeholder="Valor adicional"
          />
          <FormField
            label="Adición de Plazo"
            value={adicionPlazo}
            onChangeText={setAdicionPlazo}
            placeholder="Ej: 2 MESES"
            autoCapitalize="characters"
          />
          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <FormField
                label="Fecha Inicio Adición"
                value={adicionFechaInicio}
                onChangeText={setAdicionFechaInicio}
                placeholder="DD/MM/AAAA"
              />
            </View>
            <View style={{ flex: 1 }}>
              <FormField
                label="Fecha Fin Adición"
                value={adicionFechaFin}
                onChangeText={setAdicionFechaFin}
                placeholder="DD/MM/AAAA"
              />
            </View>
          </View>
        </View>
      )}

      <Pressable
        onPress={handleSave}
        style={({ pressed }) => [
          styles.saveBtn,
          { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
        ]}
      >
        <Feather name="save" size={18} color="#fff" />
        <Text style={styles.saveBtnText}>Crear Pago</Text>
      </Pressable>
    </KeyboardAwareScrollView>
  );
}

const styles = StyleSheet.create({
  container: { paddingHorizontal: 16, paddingTop: 16 },
  actaBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
    marginBottom: 16,
  },
  actaText: { fontFamily: "Inter_700Bold", fontSize: 16 },
  sectionHeader: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 6, marginBottom: 12, marginTop: 4 },
  sectionHeaderText: { color: "#fff", fontFamily: "Inter_700Bold", fontSize: 12, letterSpacing: 0.5 },
  row: { flexDirection: "row", gap: 12 },
  label: { fontFamily: "Inter_500Medium", fontSize: 13, marginBottom: 4 },
  hint: { fontFamily: "Inter_400Regular", fontSize: 12, marginBottom: 10 },
  switchRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  obligacionCard: { borderWidth: 1, borderRadius: 10, marginBottom: 12, overflow: "hidden" },
  obligacionHeader: { flexDirection: "row", alignItems: "flex-start", gap: 10, padding: 10 },
  obligacionNum: { fontFamily: "Inter_700Bold", fontSize: 15, minWidth: 20 },
  obligacionTitle: { fontFamily: "Inter_500Medium", fontSize: 12, flex: 1, lineHeight: 18 },
  saveBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, paddingVertical: 15, borderRadius: 12, marginTop: 12, marginBottom: 20 },
  saveBtnText: { color: "#fff", fontFamily: "Inter_700Bold", fontSize: 16 },
});
