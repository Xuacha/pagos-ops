import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { hapticMedium } from "@/utils/platform";
import { printAndSharePdf } from "@/utils/pdfPlatform";
import {
  buildFutpHtml,
  buildRetefuenteHtml,
  buildAdicionHtml,
} from "@/utils/pdfGenerator";

type DocType = "futp" | "retefuente" | "adicion";

const DOC_LABELS: Record<DocType, string> = {
  futp: "FUTP",
  retefuente: "RETEFUENTE",
  adicion: "ADICIÓN",
};

export default function PaymentPreviewScreen() {
  const { id, type } = useLocalSearchParams<{ id: string; type: string }>();
  const { profile, payments } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const [loading, setLoading] = useState(false);
  const [logoBase64, setLogoBase64] = useState<string | undefined>(undefined);

  const payment = payments.find((p) => p.id === id);
  const docType = (type as DocType) ?? "futp";

  useEffect(() => {
    if (!profile?.logoUri) return;
    if (Platform.OS === "web") {
      setLogoBase64(profile.logoUri);
      return;
    }
    // Native: convert file URI to base64
    (async () => {
      try {
        const { readAsStringAsync, EncodingType } = await import("expo-file-system");
        const b64 = await readAsStringAsync(profile.logoUri!, {
          encoding: EncodingType.Base64,
        });
        const ext = profile.logoUri!.split(".").pop()?.toLowerCase() ?? "png";
        const mime = ext === "jpg" || ext === "jpeg" ? "image/jpeg" : "image/png";
        setLogoBase64(`data:${mime};base64,${b64}`);
      } catch {
        setLogoBase64(profile.logoUri ?? undefined);
      }
    })();
  }, [profile?.logoUri]);

  const getHtml = useCallback(() => {
    if (!profile || !payment) return "<html><body>No hay datos</body></html>";
    switch (docType) {
      case "futp":      return buildFutpHtml(profile, payment, logoBase64);
      case "retefuente": return buildRetefuenteHtml(profile, payment, logoBase64);
      case "adicion":   return buildAdicionHtml(profile, payment, logoBase64);
      default:          return buildFutpHtml(profile, payment, logoBase64);
    }
  }, [profile, payment, docType, logoBase64]);

  const handlePrint = async () => {
    if (!profile || !payment) return;
    setLoading(true);
    hapticMedium();
    try {
      const html = getHtml();
      const fileName = `${docType.toUpperCase()}_Acta${payment.actaPagoNumero}_${profile.numeroContrato.replace(/[^a-zA-Z0-9]/g, "")}.pdf`;
      await printAndSharePdf(html, fileName);
    } catch (e: any) {
      Alert.alert("Aviso", e?.message ?? "No se pudo generar el PDF.");
    } finally {
      setLoading(false);
    }
  };

  if (!payment || !profile) {
    return (
      <View style={[styles.center, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.mutedForeground }}>Datos no encontrados</Text>
      </View>
    );
  }

  const html = getHtml();
  const label = DOC_LABELS[docType];

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      {/* Document type tabs */}
      <View style={[styles.typeTabs, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {(["futp", "retefuente", ...(payment.tieneAdicion ? ["adicion"] : [])] as DocType[]).map((t) => (
          <Pressable
            key={t}
            onPress={() =>
              router.replace({ pathname: "/payment/preview", params: { id, type: t } })
            }
            style={[
              styles.typeTab,
              { backgroundColor: docType === t ? colors.primary : "transparent" },
            ]}
          >
            <Text
              style={[
                styles.typeTabText,
                { color: docType === t ? "#fff" : colors.mutedForeground },
              ]}
            >
              {DOC_LABELS[t]}
            </Text>
          </Pressable>
        ))}
      </View>

      {/* Document preview */}
      {Platform.OS === "web" ? (
        <View style={styles.webContainer}>
          {/* @ts-ignore - iframe is valid on web */}
          <iframe
            srcDoc={html}
            style={{ flex: 1, border: "none", width: "100%", height: "100%" }}
            title={`Vista previa ${label}`}
          />
        </View>
      ) : (
        <NativeWebView html={html} />
      )}

      {/* Action bar */}
      <View
        style={[
          styles.actions,
          {
            backgroundColor: colors.background,
            borderTopColor: colors.border,
            paddingBottom: bottomPad + 12,
          },
        ]}
      >
        <Pressable
          onPress={() => router.back()}
          style={[styles.secondaryBtn, { borderColor: colors.border }]}
        >
          <Feather name="arrow-left" size={18} color={colors.foreground} />
          <Text style={[styles.secondaryBtnText, { color: colors.foreground }]}>Atrás</Text>
        </Pressable>
        <Pressable
          onPress={handlePrint}
          disabled={loading}
          style={({ pressed }) => [
            styles.primaryBtn,
            { backgroundColor: colors.primary, flex: 1, opacity: pressed || loading ? 0.8 : 1 },
          ]}
        >
          {loading ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <>
              <Feather name="download" size={18} color="#fff" />
              <Text style={styles.primaryBtnText}>
                {Platform.OS === "web" ? `Imprimir / Guardar ${label}` : `Descargar ${label}`}
              </Text>
            </>
          )}
        </Pressable>
      </View>
    </View>
  );
}

function NativeWebView({ html }: { html: string }) {
  const [WebView, setWebView] = useState<any>(null);
  useEffect(() => {
    import("react-native-webview").then((mod) => setWebView(() => mod.WebView));
  }, []);
  if (!WebView) return null;
  return (
    <WebView
      source={{ html }}
      style={styles.webview}
      scalesPageToFit
      showsVerticalScrollIndicator
      originWhitelist={["*"]}
    />
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  typeTabs: {
    flexDirection: "row",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
  },
  typeTab: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 8,
    flex: 1,
    alignItems: "center",
  },
  typeTabText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  webview: { flex: 1 },
  webContainer: { flex: 1 },
  actions: {
    flexDirection: "row",
    gap: 10,
    paddingHorizontal: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    elevation: 4,
  },
  secondaryBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 10,
    borderWidth: 1,
  },
  secondaryBtnText: { fontFamily: "Inter_500Medium", fontSize: 14 },
  primaryBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 13,
    borderRadius: 10,
  },
  primaryBtnText: { color: "#fff", fontFamily: "Inter_700Bold", fontSize: 14 },
});
