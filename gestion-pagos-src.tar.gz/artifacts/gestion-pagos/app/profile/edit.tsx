import { Feather } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import { router } from "expo-router";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { FormField } from "@/components/FormField";
import { useApp, UserProfile, ObligacionContractual } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const SECRETARIAS = [
  "SECRETARIA DE EDUCACION",
  "SECRETARIA DE SALUD",
  "SECRETARIA DE HACIENDA",
  "SECRETARIA DE GOBIERNO",
  "SECRETARIA DE PLANEACION",
  "SECRETARIA DE OBRAS PUBLICAS",
  "SECRETARIA DE DESARROLLO ECONOMICO",
  "SECRETARIA DE CULTURA",
  "SECRETARIA GENERAL",
  "SECRETARIA DE BIENESTAR SOCIAL",
  "OTRA",
];

function SectionHeader({ title }: { title: string }) {
  const colors = useColors();
  return (
    <View style={[styles.sectionHeader, { backgroundColor: colors.sectionHeader }]}>
      <Text style={styles.sectionHeaderText}>{title}</Text>
    </View>
  );
}

export default function ProfileEditScreen() {
  const { profile, saveProfile } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [logoUri, setLogoUri] = useState<string | null>(profile?.logoUri ?? null);
  const [secretariaOpen, setSecretariaOpen] = useState(false);
  const [obligaciones, setObligaciones] = useState<ObligacionContractual[]>(
    profile?.obligacionesContractuales ?? []
  );

  const [form, setForm] = useState({
    nombreContratista: profile?.nombreContratista ?? "",
    numeroDocumento: profile?.numeroDocumento ?? "",
    tipoContrato: profile?.tipoContrato ?? "PRESTACION DE SERVICIOS",
    numeroContrato: profile?.numeroContrato ?? "",
    fechaSuscripcion: profile?.fechaSuscripcion ?? "",
    objetoContractual: profile?.objetoContractual ?? "",
    valorTotalContrato: String(profile?.valorTotalContrato ?? ""),
    plazoContrato: profile?.plazoContrato ?? "",
    fechaInicioContrato: profile?.fechaInicioContrato ?? "",
    fechaTerminacionContrato: profile?.fechaTerminacionContrato ?? "",
    noCrpFecha: profile?.noCrpFecha ?? "",
    noRubroCrp: profile?.noRubroCrp ?? "",
    fechaGarantia: profile?.fechaGarantia ?? "",
    dependencia: profile?.dependencia ?? "",
    supervisorCargo: profile?.supervisorCargo ?? "",
    entidadFinanciera: profile?.entidadFinanciera ?? "",
    numeroCuenta: profile?.numeroCuenta ?? "",
    tipoCuenta: profile?.tipoCuenta ?? "AHORROS",
    actividadEconomicaCIIU: profile?.actividadEconomicaCIIU ?? "8299",
    regimenVentas: profile?.regimenVentas ?? "NO Responsable de IVA",
    noFactura: profile?.noFactura ?? "",
    salud: profile?.salud ?? "",
    pension: profile?.pension ?? "",
    arl: profile?.arl ?? "",
    lePaganPension: profile?.lePaganPension ?? false,
    entidadPension: profile?.entidadPension ?? "",
    municipioRealiza: profile?.municipioRealiza ?? false,
    secretaria: profile?.secretaria ?? "",
    reservaPresupuestal: profile?.reservaPresupuestal ?? false,
  });

  const set = (key: string, value: string | boolean) =>
    setForm((f) => ({ ...f, [key]: value }));

  const pickLogo = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });
    if (!result.canceled) setLogoUri(result.assets[0].uri);
  };

  const addObligacion = () => {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 5);
    setObligaciones((prev) => [
      ...prev,
      { id, obligacion: "", actividad: "", evidencia: "" },
    ]);
  };

  const updateOb = (id: string, field: keyof ObligacionContractual, value: string) => {
    setObligaciones((prev) =>
      prev.map((o) => (o.id === id ? { ...o, [field]: value } : o))
    );
  };

  const removeOb = (id: string) => {
    if (obligaciones.length === 1) return;
    setObligaciones((prev) => prev.filter((o) => o.id !== id));
  };

  const handleSave = async () => {
    if (!profile) return;
    if (!form.nombreContratista || !form.numeroDocumento) {
      Alert.alert("Error", "Nombre y documento son requeridos.");
      return;
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    const updated: UserProfile = {
      ...profile,
      ...form,
      valorTotalContrato: parseFloat(form.valorTotalContrato.replace(/[.,]/g, "")) || 0,
      logoUri,
      obligacionesContractuales: obligaciones,
    };
    await saveProfile(updated);
    router.back();
  };

  if (!profile) return null;

  return (
    <KeyboardAwareScrollView
      style={{ backgroundColor: colors.background }}
      contentContainerStyle={[styles.container, { paddingBottom: insets.bottom + 40 }]}
      keyboardShouldPersistTaps="handled"
      bottomOffset={20}
    >
      <SectionHeader title="LOGO DE LA ALCALDÍA" />
      <View style={styles.logoSection}>
        <Pressable
          onPress={pickLogo}
          style={[styles.logoPicker, { borderColor: colors.primary, backgroundColor: colors.primary + "0A" }]}
        >
          {logoUri ? (
            <Image source={{ uri: logoUri }} style={styles.logoPreview} />
          ) : (
            <>
              <Feather name="upload" size={28} color={colors.primary} />
              <Text style={[styles.logoText, { color: colors.primary }]}>Cargar logo</Text>
            </>
          )}
        </Pressable>
        {logoUri && (
          <Pressable onPress={() => setLogoUri(null)} style={styles.removeBtn}>
            <Feather name="x" size={14} color={colors.destructive} />
            <Text style={[{ color: colors.destructive, fontFamily: "Inter_400Regular", fontSize: 12 }]}>Quitar logo</Text>
          </Pressable>
        )}
      </View>

      <SectionHeader title="SECRETARÍA" />
      <View style={styles.section}>
        <Text style={[styles.label, { color: colors.foreground }]}>Secretaría</Text>
        <Pressable
          onPress={() => setSecretariaOpen(!secretariaOpen)}
          style={[styles.selector, { backgroundColor: colors.card, borderColor: colors.border }]}
        >
          <Text style={{ flex: 1, fontFamily: "Inter_400Regular", fontSize: 14, color: form.secretaria ? colors.foreground : colors.mutedForeground }}>
            {form.secretaria || "Seleccionar"}
          </Text>
          <Feather name={secretariaOpen ? "chevron-up" : "chevron-down"} size={18} color={colors.mutedForeground} />
        </Pressable>
        {secretariaOpen && (
          <View style={[styles.dropdown, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {SECRETARIAS.map((s) => (
              <Pressable
                key={s}
                onPress={() => { set("secretaria", s); setSecretariaOpen(false); }}
                style={{ paddingHorizontal: 14, paddingVertical: 10, backgroundColor: form.secretaria === s ? colors.primary + "18" : "transparent" }}
              >
                <Text style={{ fontFamily: form.secretaria === s ? "Inter_600SemiBold" : "Inter_400Regular", fontSize: 13, color: form.secretaria === s ? colors.primary : colors.foreground }}>
                  {s}
                </Text>
              </Pressable>
            ))}
          </View>
        )}
      </View>

      <SectionHeader title="DATOS DEL CONTRATISTA" />
      <View style={styles.section}>
        <FormField label="Nombre Completo" required value={form.nombreContratista} onChangeText={(t) => set("nombreContratista", t)} autoCapitalize="characters" />
        <FormField label="No. Identificación" required value={form.numeroDocumento} onChangeText={(t) => set("numeroDocumento", t)} keyboardType="number-pad" />
        <FormField label="No. Contrato y Fecha" value={form.numeroContrato} onChangeText={(t) => set("numeroContrato", t)} />
        <FormField label="Tipo de Contrato" value={form.tipoContrato} onChangeText={(t) => set("tipoContrato", t)} autoCapitalize="characters" />
        <FormField label="Objeto Contractual" value={form.objetoContractual} onChangeText={(t) => set("objetoContractual", t)} multiline numberOfLines={3} style={{ minHeight: 80, textAlignVertical: "top" }} />
        <FormField label="Valor Total ($)" value={form.valorTotalContrato} onChangeText={(t) => set("valorTotalContrato", t)} keyboardType="number-pad" />
        <FormField label="Plazo" value={form.plazoContrato} onChangeText={(t) => set("plazoContrato", t)} autoCapitalize="characters" />
        <FormField label="Fecha Inicio" value={form.fechaInicioContrato} onChangeText={(t) => set("fechaInicioContrato", t)} placeholder="DD/MM/AAAA" />
        <FormField label="Fecha Terminación" value={form.fechaTerminacionContrato} onChangeText={(t) => set("fechaTerminacionContrato", t)} placeholder="DD/MM/AAAA" />
        <FormField label="No. CRP y Fecha" value={form.noCrpFecha} onChangeText={(t) => set("noCrpFecha", t)} />
        <FormField label="No. Rubro CRP" value={form.noRubroCrp} onChangeText={(t) => set("noRubroCrp", t)} />
        <FormField label="Fecha Garantía (si aplica)" value={form.fechaGarantia} onChangeText={(t) => set("fechaGarantia", t)} placeholder="DD/MM/AAAA" />
        <FormField label="Dependencia" value={form.dependencia} onChangeText={(t) => set("dependencia", t)} autoCapitalize="characters" />
        <FormField label="Supervisor – Cargo" value={form.supervisorCargo} onChangeText={(t) => set("supervisorCargo", t)} autoCapitalize="characters" />
        <View style={styles.switchRow}>
          <Text style={[styles.label, { color: colors.foreground }]}>Reserva Presupuestal</Text>
          <Switch value={form.reservaPresupuestal} onValueChange={(v) => set("reservaPresupuestal", v)} trackColor={{ true: colors.primary }} />
        </View>
      </View>

      <SectionHeader title="DATOS BANCARIOS" />
      <View style={styles.section}>
        <FormField label="Entidad Financiera" value={form.entidadFinanciera} onChangeText={(t) => set("entidadFinanciera", t)} autoCapitalize="characters" />
        <FormField label="Número de Cuenta" value={form.numeroCuenta} onChangeText={(t) => set("numeroCuenta", t)} keyboardType="number-pad" />
        <FormField label="Tipo de Cuenta" value={form.tipoCuenta} onChangeText={(t) => set("tipoCuenta", t)} autoCapitalize="characters" />
        <FormField label="CIIU" value={form.actividadEconomicaCIIU} onChangeText={(t) => set("actividadEconomicaCIIU", t)} />
        <FormField label="Régimen Ventas" value={form.regimenVentas} onChangeText={(t) => set("regimenVentas", t)} />
        <FormField label="No. Factura" value={form.noFactura} onChangeText={(t) => set("noFactura", t)} />
      </View>

      <SectionHeader title="SEGURIDAD SOCIAL" />
      <View style={styles.section}>
        <FormField label="Salud" value={form.salud} onChangeText={(t) => set("salud", t)} autoCapitalize="characters" />
        <FormField label="Pensión" value={form.pension} onChangeText={(t) => set("pension", t)} autoCapitalize="characters" />
        <FormField label="ARL" value={form.arl} onChangeText={(t) => set("arl", t)} autoCapitalize="characters" />
        <View style={styles.switchRow}>
          <Text style={[styles.label, { color: colors.foreground }]}>¿Pensión reconocida?</Text>
          <Switch value={form.lePaganPension} onValueChange={(v) => set("lePaganPension", v)} trackColor={{ true: colors.primary }} />
        </View>
        {form.lePaganPension && (
          <FormField label="Entidad que reconoció la pensión" value={form.entidadPension} onChangeText={(t) => set("entidadPension", t)} />
        )}
        <View style={styles.switchRow}>
          <Text style={[styles.label, { color: colors.foreground, flex: 1 }]}>¿Municipio realiza aportes ARL?</Text>
          <Switch value={form.municipioRealiza} onValueChange={(v) => set("municipioRealiza", v)} trackColor={{ true: colors.primary }} />
        </View>
      </View>

      <SectionHeader title="OBLIGACIONES CONTRACTUALES" />
      <View style={styles.section}>
        {obligaciones.map((ob, idx) => (
          <View key={ob.id} style={[styles.obligacionCard, { borderColor: colors.border, backgroundColor: colors.card }]}>
            <View style={styles.obligacionHeader}>
              <Text style={[styles.obligacionNum, { color: colors.primary, backgroundColor: colors.primary + "18" }]}>{idx + 1}</Text>
              {obligaciones.length > 1 && (
                <Pressable onPress={() => removeOb(ob.id)} hitSlop={10}>
                  <Feather name="trash-2" size={16} color={colors.destructive} />
                </Pressable>
              )}
            </View>
            <FormField label="Obligación" value={ob.obligacion} onChangeText={(t) => updateOb(ob.id, "obligacion", t)} multiline numberOfLines={2} style={{ minHeight: 60, textAlignVertical: "top" }} />
            <FormField label="Actividad (por defecto)" value={ob.actividad} onChangeText={(t) => updateOb(ob.id, "actividad", t)} multiline numberOfLines={2} style={{ minHeight: 60, textAlignVertical: "top" }} />
            <FormField label="Evidencia (por defecto)" value={ob.evidencia} onChangeText={(t) => updateOb(ob.id, "evidencia", t)} multiline numberOfLines={2} style={{ minHeight: 60, textAlignVertical: "top" }} />
          </View>
        ))}
        <Pressable onPress={addObligacion} style={[styles.addBtn, { borderColor: colors.primary, backgroundColor: colors.primary + "0A" }]}>
          <Feather name="plus-circle" size={16} color={colors.primary} />
          <Text style={[styles.addBtnText, { color: colors.primary }]}>Agregar Obligación</Text>
        </Pressable>
      </View>

      <Pressable
        onPress={handleSave}
        style={({ pressed }) => [styles.saveBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}
      >
        <Feather name="save" size={18} color="#fff" />
        <Text style={styles.saveBtnText}>Guardar Cambios</Text>
      </Pressable>
    </KeyboardAwareScrollView>
  );
}

const styles = StyleSheet.create({
  container: { paddingHorizontal: 16, paddingTop: 16 },
  sectionHeader: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 6, marginBottom: 12, marginTop: 4 },
  sectionHeaderText: { color: "#fff", fontFamily: "Inter_700Bold", fontSize: 12, letterSpacing: 0.5 },
  section: { marginBottom: 8 },
  label: { fontFamily: "Inter_500Medium", fontSize: 13, marginBottom: 6 },
  logoSection: { alignItems: "center", marginBottom: 16 },
  logoPicker: { width: 110, height: 110, borderRadius: 16, borderWidth: 2, borderStyle: "dashed", alignItems: "center", justifyContent: "center", gap: 8 },
  logoPreview: { width: 106, height: 106, borderRadius: 14 },
  logoText: { fontFamily: "Inter_500Medium", fontSize: 12, textAlign: "center" },
  removeBtn: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 6 },
  selector: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 11, minHeight: 44, marginBottom: 12 },
  dropdown: { borderWidth: 1, borderRadius: 10, marginTop: 4, overflow: "hidden", elevation: 3, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.12, shadowRadius: 4, marginBottom: 12 },
  switchRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 12 },
  obligacionCard: { borderWidth: 1, borderRadius: 10, padding: 12, marginBottom: 12, gap: 4 },
  obligacionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 },
  obligacionNum: { width: 28, height: 28, borderRadius: 14, textAlign: "center", lineHeight: 28, fontFamily: "Inter_700Bold", fontSize: 13 },
  addBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingVertical: 12, borderRadius: 10, borderWidth: 1, borderStyle: "dashed", marginBottom: 16 },
  addBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  saveBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, paddingVertical: 15, borderRadius: 12, marginBottom: 20, marginTop: 8 },
  saveBtnText: { color: "#fff", fontFamily: "Inter_700Bold", fontSize: 16 },
});
