import { Feather } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import { router } from "expo-router";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  Image,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import { KeyboardAwareScrollView } from "react-native-keyboard-controller";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { FormField } from "@/components/FormField";
import { useApp, UserProfile, ObligacionContractual } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

const SECRETARIAS = [
  "SECRETARIA DE EDUCACION",
  "SECRETARIA DE SALUD",
  "SECRETARIA DE HACIENDA",
  "SECRETARIA DE GOBIERNO",
  "SECRETARIA DE PLANEACION",
  "SECRETARIA DE OBRAS PUBLICAS",
  "SECRETARIA DE DESARROLLO ECONOMICO",
  "SECRETARIA DE CULTURA",
  "SECRETARIA GENERAL",
  "SECRETARIA DE BIENESTAR SOCIAL",
  "OTRA",
];

function SectionHeader({ title }: { title: string }) {
  const colors = useColors();
  return (
    <View style={[styles.sectionHeader, { backgroundColor: colors.sectionHeader }]}>
      <Text style={styles.sectionHeaderText}>{title}</Text>
    </View>
  );
}

function SecretariaSelector({
  value,
  onSelect,
}: {
  value: string;
  onSelect: (s: string) => void;
}) {
  const colors = useColors();
  const [open, setOpen] = useState(false);

  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={[styles.label, { color: colors.foreground }]}>
        Secretaría <Text style={{ color: colors.destructive }}>*</Text>
      </Text>
      <Pressable
        onPress={() => setOpen(!open)}
        style={[
          styles.selector,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        <Text
          style={{
            fontFamily: "Inter_400Regular",
            fontSize: 14,
            color: value ? colors.foreground : colors.mutedForeground,
            flex: 1,
          }}
        >
          {value || "Seleccione una secretaría"}
        </Text>
        <Feather
          name={open ? "chevron-up" : "chevron-down"}
          size={18}
          color={colors.mutedForeground}
        />
      </Pressable>
      {open && (
        <View
          style={[
            styles.dropdown,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          {SECRETARIAS.map((s) => (
            <Pressable
              key={s}
              onPress={() => {
                onSelect(s);
                setOpen(false);
              }}
              style={[
                styles.dropdownItem,
                {
                  backgroundColor:
                    value === s ? colors.primary + "18" : "transparent",
                },
              ]}
            >
              <Text
                style={{
                  fontFamily:
                    value === s ? "Inter_600SemiBold" : "Inter_400Regular",
                  fontSize: 13,
                  color: value === s ? colors.primary : colors.foreground,
                }}
              >
                {s}
              </Text>
            </Pressable>
          ))}
        </View>
      )}
    </View>
  );
}

export default function ProfileSetupScreen() {
  const { saveProfile } = useApp();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const [logoUri, setLogoUri] = useState<string | null>(null);
  const [form, setForm] = useState({
    nombreContratista: "",
    numeroDocumento: "",
    tipoContrato: "PRESTACION DE SERVICIOS",
    numeroContrato: "",
    fechaSuscripcion: "",
    objetoContractual: "",
    valorTotalContrato: "",
    plazoContrato: "",
    fechaInicioContrato: "",
    fechaTerminacionContrato: "",
    noCrpFecha: "",
    noRubroCrp: "",
    fechaGarantia: "",
    dependencia: "",
    supervisorCargo: "",
    entidadFinanciera: "",
    numeroCuenta: "",
    tipoCuenta: "AHORROS",
    actividadEconomicaCIIU: "8299",
    regimenVentas: "NO Responsable de IVA",
    noFactura: "",
    salud: "",
    pension: "",
    arl: "",
    lePaganPension: false,
    entidadPension: "",
    municipioRealiza: false,
    secretaria: "",
    reservaPresupuestal: false,
  });

  const [obligaciones, setObligaciones] = useState<ObligacionContractual[]>([
    {
      id: `${Date.now()}1`,
      obligacion: "",
      actividad: "",
      evidencia: "",
    },
  ]);

  const set = (key: string, value: string | boolean) =>
    setForm((f) => ({ ...f, [key]: value }));

  const pickLogo = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: "images",
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });
    if (!result.canceled) {
      setLogoUri(result.assets[0].uri);
    }
  };

  const addObligacion = () => {
    const id = Date.now().toString() + Math.random().toString(36).substr(2, 5);
    setObligaciones((prev) => [
      ...prev,
      { id, obligacion: "", actividad: "", evidencia: "" },
    ]);
  };

  const updateObligacion = (
    id: string,
    field: keyof ObligacionContractual,
    value: string
  ) => {
    setObligaciones((prev) =>
      prev.map((o) => (o.id === id ? { ...o, [field]: value } : o))
    );
  };

  const removeObligacion = (id: string) => {
    if (obligaciones.length === 1) return;
    setObligaciones((prev) => prev.filter((o) => o.id !== id));
  };

  const handleSave = async () => {
    if (!form.nombreContratista || !form.numeroDocumento || !form.numeroContrato || !form.secretaria) {
      Alert.alert("Campos requeridos", "Por favor completa los campos obligatorios.");
      return;
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    const profile: UserProfile = {
      id: Date.now().toString(),
      ...form,
      valorTotalContrato: parseFloat(form.valorTotalContrato.replace(/[.,]/g, "")) || 0,
      logoUri,
      obligacionesContractuales: obligaciones,
    };
    await saveProfile(profile);
    router.replace("/");
  };

  return (
    <KeyboardAwareScrollView
      style={{ backgroundColor: colors.background }}
      contentContainerStyle={[
        styles.container,
        { paddingBottom: insets.bottom + 40 },
      ]}
      keyboardShouldPersistTaps="handled"
      bottomOffset={20}
    >
      {/* Logo */}
      <SectionHeader title="LOGO DE LA ALCALDÍA" />
      <View style={styles.logoSection}>
        <Pressable
          onPress={pickLogo}
          style={[
            styles.logoPicker,
            { borderColor: colors.primary, backgroundColor: colors.primary + "0A" },
          ]}
        >
          {logoUri ? (
            <Image source={{ uri: logoUri }} style={styles.logoPreview} />
          ) : (
            <>
              <Feather name="upload" size={28} color={colors.primary} />
              <Text style={[styles.logoText, { color: colors.primary }]}>
                Toca para cargar el logo
              </Text>
            </>
          )}
        </Pressable>
        {logoUri && (
          <Pressable onPress={() => setLogoUri(null)} style={styles.removeBtn}>
            <Feather name="x" size={14} color={colors.destructive} />
            <Text style={[styles.removeTxt, { color: colors.destructive }]}>
              Quitar logo
            </Text>
          </Pressable>
        )}
      </View>

      {/* Secretaría */}
      <SectionHeader title="SECRETARÍA" />
      <View style={styles.section}>
        <SecretariaSelector
          value={form.secretaria}
          onSelect={(s) => set("secretaria", s)}
        />
        {form.secretaria === "OTRA" && (
          <FormField
            label="Nombre de la Secretaría"
            value={form.secretaria}
            onChangeText={(t) => set("secretaria", t)}
            placeholder="Ingrese el nombre"
          />
        )}
      </View>

      {/* Datos del Contratista */}
      <SectionHeader title="I. DATOS DEL CONTRATISTA" />
      <View style={styles.section}>
        <FormField
          label="Nombre Completo"
          required
          value={form.nombreContratista}
          onChangeText={(t) => set("nombreContratista", t)}
          placeholder="Nombre y apellidos"
          autoCapitalize="characters"
        />
        <FormField
          label="No. Identificación (CC – NIT)"
          required
          value={form.numeroDocumento}
          onChangeText={(t) => set("numeroDocumento", t)}
          placeholder="Número de documento"
          keyboardType="number-pad"
        />
        <FormField
          label="No. Contrato y Fecha Suscripción"
          required
          value={form.numeroContrato}
          onChangeText={(t) => set("numeroContrato", t)}
          placeholder="Ej: 0281 - 5/01/2026"
        />
        <FormField
          label="Tipo de Contrato"
          value={form.tipoContrato}
          onChangeText={(t) => set("tipoContrato", t)}
          placeholder="PRESTACION DE SERVICIOS"
          autoCapitalize="characters"
        />
        <FormField
          label="Objeto Contractual"
          required
          value={form.objetoContractual}
          onChangeText={(t) => set("objetoContractual", t)}
          placeholder="Descripción del objeto"
          multiline
          numberOfLines={3}
          style={{ minHeight: 80, textAlignVertical: "top" }}
        />
        <FormField
          label="Valor Total del Contrato ($)"
          value={form.valorTotalContrato}
          onChangeText={(t) => set("valorTotalContrato", t)}
          placeholder="10176000"
          keyboardType="number-pad"
        />
        <FormField
          label="Plazo Total del Contrato"
          value={form.plazoContrato}
          onChangeText={(t) => set("plazoContrato", t)}
          placeholder="4 MESES"
          autoCapitalize="characters"
        />
        <FormField
          label="Fecha de Inicio Contrato"
          value={form.fechaInicioContrato}
          onChangeText={(t) => set("fechaInicioContrato", t)}
          placeholder="DD/MM/AAAA"
        />
        <FormField
          label="Fecha de Terminación Contrato"
          value={form.fechaTerminacionContrato}
          onChangeText={(t) => set("fechaTerminacionContrato", t)}
          placeholder="DD/MM/AAAA"
        />
        <FormField
          label="No. CRP y Fecha de Expedición"
          value={form.noCrpFecha}
          onChangeText={(t) => set("noCrpFecha", t)}
          placeholder="479- 7/ENERO/2026"
        />
        <FormField
          label="No. Del Rubro de CRP"
          value={form.noRubroCrp}
          onChangeText={(t) => set("noRubroCrp", t)}
          placeholder="0110-2.3.22..."
        />
        <FormField
          label="Fecha Aprobación Garantía (si aplica)"
          value={form.fechaGarantia}
          onChangeText={(t) => set("fechaGarantia", t)}
          placeholder="DD/MM/AAAA"
        />
        <FormField
          label="Dependencia"
          value={form.dependencia}
          onChangeText={(t) => set("dependencia", t)}
          placeholder="INSTITUCION EDUCATIVA..."
          autoCapitalize="characters"
        />
        <FormField
          label="Supervisor – Cargo"
          value={form.supervisorCargo}
          onChangeText={(t) => set("supervisorCargo", t)}
          placeholder="NOMBRE - CARGO"
          autoCapitalize="characters"
        />

        <View style={styles.switchRow}>
          <Text style={[styles.label, { color: colors.foreground }]}>
            Reserva Presupuestal
          </Text>
          <Switch
            value={form.reservaPresupuestal}
            onValueChange={(v) => set("reservaPresupuestal", v)}
            trackColor={{ true: colors.primary }}
          />
        </View>
      </View>

      {/* Datos Bancarios */}
      <SectionHeader title="DATOS BANCARIOS" />
      <View style={styles.section}>
        <FormField
          label="Entidad Financiera"
          value={form.entidadFinanciera}
          onChangeText={(t) => set("entidadFinanciera", t)}
          placeholder="CAJA SOCIAL"
          autoCapitalize="characters"
        />
        <FormField
          label="Número de Cuenta"
          value={form.numeroCuenta}
          onChangeText={(t) => set("numeroCuenta", t)}
          placeholder="Número de cuenta"
          keyboardType="number-pad"
        />
        <FormField
          label="Tipo de Cuenta"
          value={form.tipoCuenta}
          onChangeText={(t) => set("tipoCuenta", t)}
          placeholder="AHORROS / CORRIENTE"
          autoCapitalize="characters"
        />
        <FormField
          label="Actividad Económica CIIU"
          value={form.actividadEconomicaCIIU}
          onChangeText={(t) => set("actividadEconomicaCIIU", t)}
          placeholder="8299"
          keyboardType="number-pad"
        />
        <FormField
          label="Régimen en Ventas"
          value={form.regimenVentas}
          onChangeText={(t) => set("regimenVentas", t)}
          placeholder="NO Responsable de IVA"
        />
        <FormField
          label="No. Factura"
          value={form.noFactura}
          onChangeText={(t) => set("noFactura", t)}
          placeholder="Número de factura (si aplica)"
        />
      </View>

      {/* Seguridad Social */}
      <SectionHeader title="III. SEGURIDAD SOCIAL" />
      <View style={styles.section}>
        <FormField
          label="Entidad de Salud"
          value={form.salud}
          onChangeText={(t) => set("salud", t)}
          placeholder="SANITAS / SURA / ETC"
          autoCapitalize="characters"
        />
        <FormField
          label="Entidad de Pensión"
          value={form.pension}
          onChangeText={(t) => set("pension", t)}
          placeholder="PORVENIR / COLPENSIONES / ETC"
          autoCapitalize="characters"
        />
        <FormField
          label="ARL"
          value={form.arl}
          onChangeText={(t) => set("arl", t)}
          placeholder="AURORA / POSITIVA / ETC"
          autoCapitalize="characters"
        />
        <View style={styles.switchRow}>
          <Text style={[styles.label, { color: colors.foreground }]}>
            ¿Le han reconocido pensión?
          </Text>
          <Switch
            value={form.lePaganPension}
            onValueChange={(v) => set("lePaganPension", v)}
            trackColor={{ true: colors.primary }}
          />
        </View>
        {form.lePaganPension && (
          <FormField
            label="Entidad que lo reconoció"
            value={form.entidadPension}
            onChangeText={(t) => set("entidadPension", t)}
            placeholder="Nombre de la entidad"
          />
        )}
        <View style={styles.switchRow}>
          <Text style={[styles.label, { color: colors.foreground, flex: 1 }]}>
            ¿La admin. municipal realiza aportes ARL?
          </Text>
          <Switch
            value={form.municipioRealiza}
            onValueChange={(v) => set("municipioRealiza", v)}
            trackColor={{ true: colors.primary }}
          />
        </View>
      </View>

      {/* Obligaciones Contractuales */}
      <SectionHeader title="II. OBLIGACIONES CONTRACTUALES" />
      <View style={styles.section}>
        <Text style={[styles.hint, { color: colors.mutedForeground }]}>
          Agrega las obligaciones del contrato. Puedes modificar las actividades y evidencias en cada pago.
        </Text>
        {obligaciones.map((ob, idx) => (
          <View
            key={ob.id}
            style={[
              styles.obligacionCard,
              { borderColor: colors.border, backgroundColor: colors.card },
            ]}
          >
            <View style={styles.obligacionHeader}>
              <Text
                style={[
                  styles.obligacionNum,
                  { color: colors.primary, backgroundColor: colors.primary + "18" },
                ]}
              >
                {idx + 1}
              </Text>
              {obligaciones.length > 1 && (
                <Pressable
                  onPress={() => removeObligacion(ob.id)}
                  hitSlop={10}
                >
                  <Feather name="trash-2" size={16} color={colors.destructive} />
                </Pressable>
              )}
            </View>
            <FormField
              label="Obligación Contractual"
              value={ob.obligacion}
              onChangeText={(t) => updateObligacion(ob.id, "obligacion", t)}
              placeholder="Texto de la obligación"
              multiline
              numberOfLines={2}
              style={{ minHeight: 60, textAlignVertical: "top" }}
            />
            <FormField
              label="Actividad (por defecto)"
              value={ob.actividad}
              onChangeText={(t) => updateObligacion(ob.id, "actividad", t)}
              placeholder="Actividad realizada"
              multiline
              numberOfLines={2}
              style={{ minHeight: 60, textAlignVertical: "top" }}
            />
            <FormField
              label="Evidencia (por defecto)"
              value={ob.evidencia}
              onChangeText={(t) => updateObligacion(ob.id, "evidencia", t)}
              placeholder="Evidencia verificable"
              multiline
              numberOfLines={2}
              style={{ minHeight: 60, textAlignVertical: "top" }}
            />
          </View>
        ))}
        <Pressable
          onPress={addObligacion}
          style={[
            styles.addBtn,
            { borderColor: colors.primary, backgroundColor: colors.primary + "0A" },
          ]}
        >
          <Feather name="plus-circle" size={16} color={colors.primary} />
          <Text style={[styles.addBtnText, { color: colors.primary }]}>
            Agregar Obligación
          </Text>
        </Pressable>
      </View>

      {/* Save */}
      <Pressable
        onPress={handleSave}
        style={({ pressed }) => [
          styles.saveBtn,
          { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 },
        ]}
      >
        <Feather name="save" size={18} color="#fff" />
        <Text style={styles.saveBtnText}>Guardar Perfil</Text>
      </Pressable>
    </KeyboardAwareScrollView>
  );
}

const styles = StyleSheet.create({
  container: { paddingHorizontal: 16, paddingTop: 16 },
  sectionHeader: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 6,
    marginBottom: 12,
    marginTop: 4,
  },
  sectionHeaderText: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 12,
    letterSpacing: 0.5,
  },
  section: { marginBottom: 8 },
  label: { fontFamily: "Inter_500Medium", fontSize: 13 },
  hint: { fontFamily: "Inter_400Regular", fontSize: 12, marginBottom: 10 },
  logoSection: { alignItems: "center", marginBottom: 16 },
  logoPicker: {
    width: 110,
    height: 110,
    borderRadius: 16,
    borderWidth: 2,
    borderStyle: "dashed",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  logoPreview: { width: 106, height: 106, borderRadius: 14 },
  logoText: { fontFamily: "Inter_500Medium", fontSize: 12, textAlign: "center" },
  removeBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: 6,
  },
  removeTxt: { fontFamily: "Inter_400Regular", fontSize: 12 },
  selector: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 11,
    minHeight: 44,
  },
  dropdown: {
    borderWidth: 1,
    borderRadius: 10,
    marginTop: 4,
    overflow: "hidden",
    elevation: 3,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 4,
  },
  dropdownItem: { paddingHorizontal: 14, paddingVertical: 10 },
  switchRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  obligacionCard: {
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    marginBottom: 12,
    gap: 4,
  },
  obligacionHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 8,
  },
  obligacionNum: {
    width: 28,
    height: 28,
    borderRadius: 14,
    textAlign: "center",
    lineHeight: 28,
    fontFamily: "Inter_700Bold",
    fontSize: 13,
  },
  addBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderStyle: "dashed",
    marginBottom: 16,
  },
  addBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 14 },
  saveBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingVertical: 15,
    borderRadius: 12,
    marginBottom: 20,
    marginTop: 8,
  },
  saveBtnText: {
    color: "#fff",
    fontFamily: "Inter_700Bold",
    fontSize: 16,
  },
});
