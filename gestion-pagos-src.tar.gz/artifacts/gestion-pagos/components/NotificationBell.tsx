import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { useNotifications } from "@/context/NotificationContext";
import { useColors } from "@/hooks/useColors";

export function NotificationBell() {
  const { unreadCount } = useNotifications();
  const colors = useColors();

  return (
    <Pressable
      onPress={() => router.push("/notificaciones")}
      hitSlop={12}
      style={styles.wrap}
    >
      <Feather name="bell" size={20} color="rgba(255,255,255,0.9)" />
      {unreadCount > 0 && (
        <View style={[styles.badge, { backgroundColor: colors.gold }]}>
          <Text style={styles.badgeText}>
            {unreadCount > 9 ? "9+" : unreadCount}
          </Text>
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrap: { position: "relative", padding: 2 },
  badge: {
    position: "absolute",
    top: -4,
    right: -4,
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 3,
  },
  badgeText: {
    color: "#fff",
    fontSize: 9,
    fontFamily: "Inter_700Bold",
  },
});
