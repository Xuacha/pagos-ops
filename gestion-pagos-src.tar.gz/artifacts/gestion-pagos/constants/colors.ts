const colors = {
  light: {
    text: "#1a2332",
    tint: "#1e4f8f",

    background: "#f4f6f9",
    foreground: "#1a2332",

    card: "#ffffff",
    cardForeground: "#1a2332",

    primary: "#1e4f8f",
    primaryForeground: "#ffffff",

    secondary: "#e8edf5",
    secondaryForeground: "#1a2332",

    muted: "#eef1f6",
    mutedForeground: "#6b7a94",

    accent: "#c9a227",
    accentForeground: "#ffffff",

    destructive: "#c0392b",
    destructiveForeground: "#ffffff",

    border: "#d0d9e8",
    input: "#d0d9e8",

    success: "#27ae60",
    successForeground: "#ffffff",

    surface: "#ffffff",
    headerBg: "#1e4f8f",
    headerText: "#ffffff",
    sectionHeader: "#2c5f9e",
    tableHeader: "#2c5f9e",
    tableRow: "#f8f9fb",
    tableAlt: "#eef1f6",
    gold: "#c9a227",
    divider: "#d0d9e8",
  },
  radius: 10,
};

export default colors;
