import AsyncStorage from "@react-native-async-storage/async-storage";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

export interface UserProfile {
  id: string;
  nombreContratista: string;
  numeroDocumento: string;
  tipoContrato: string;
  numeroContrato: string;
  fechaSuscripcion: string;
  objetoContractual: string;
  valorTotalContrato: number;
  plazoContrato: string;
  fechaInicioContrato: string;
  fechaTerminacionContrato: string;
  noCrpFecha: string;
  noRubroCrp: string;
  fechaGarantia: string;
  dependencia: string;
  supervisorCargo: string;
  entidadFinanciera: string;
  numeroCuenta: string;
  tipoCuenta: string;
  actividadEconomicaCIIU: string;
  regimenVentas: string;
  noFactura: string;
  salud: string;
  pension: string;
  arl: string;
  lePaganPension: boolean;
  entidadPension: string;
  municipioRealiza: boolean;
  secretaria: string;
  logoUri: string | null;
  obligacionesContractuales: ObligacionContractual[];
  reservaPresupuestal: boolean;
}

export interface ObligacionContractual {
  id: string;
  obligacion: string;
  actividad: string;
  evidencia: string;
}

export interface Payment {
  id: string;
  profileId: string;
  actaPagoNumero: number;
  periodoDesde: string;
  periodoHasta: string;
  valorPagoNumeros: number;
  valorPagoLetras: string;
  periodoPagoSeguridad: string;
  noPlanilla: string;
  fechaCreacion: string;
  obligacionesDetalle: ObligacionDetalle[];
  adicionValor?: number;
  adicionPlazo?: string;
  adicionFechaInicio?: string;
  adicionFechaFin?: string;
  tieneAdicion: boolean;
  valorInicial: number;
  valorAdiciones: number;
  anticipos: { anticipo1: number; anticipo2: number };
  amortizaciones: number;
}

export interface ObligacionDetalle {
  id: string;
  obligacionId: string;
  actividad: string;
  evidencia: string;
}

interface AppContextType {
  profile: UserProfile | null;
  payments: Payment[];
  saveProfile: (profile: UserProfile) => Promise<void>;
  savePayment: (payment: Payment) => Promise<void>;
  deletePayment: (id: string) => Promise<void>;
  isLoading: boolean;
}

const AppContext = createContext<AppContextType | null>(null);

const PROFILE_KEY = "@futp_profile";
const PAYMENTS_KEY = "@futp_payments";

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [profileJson, paymentsJson] = await Promise.all([
        AsyncStorage.getItem(PROFILE_KEY),
        AsyncStorage.getItem(PAYMENTS_KEY),
      ]);
      if (profileJson) setProfile(JSON.parse(profileJson));
      if (paymentsJson) setPayments(JSON.parse(paymentsJson));
    } catch (e) {
      console.warn("Error loading data", e);
    } finally {
      setIsLoading(false);
    }
  };

  const saveProfile = useCallback(async (newProfile: UserProfile) => {
    await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(newProfile));
    setProfile(newProfile);
  }, []);

  const savePayment = useCallback(async (payment: Payment) => {
    setPayments((prev) => {
      const idx = prev.findIndex((p) => p.id === payment.id);
      const updated =
        idx >= 0
          ? prev.map((p) => (p.id === payment.id ? payment : p))
          : [...prev, payment];
      AsyncStorage.setItem(PAYMENTS_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  const deletePayment = useCallback(async (id: string) => {
    setPayments((prev) => {
      const updated = prev.filter((p) => p.id !== id);
      AsyncStorage.setItem(PAYMENTS_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  return (
    <AppContext.Provider
      value={{
        profile,
        payments,
        saveProfile,
        savePayment,
        deletePayment,
        isLoading,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}
