import { UserProfile, Payment } from "@/context/AppContext";
import { supabase } from "./supabase";

// ─── Types ────────────────────────────────────────────────────────────────────

export type UserRole = "contratista" | "admin";
export type SubmissionState = "pendiente" | "aprobado" | "rechazado_parcial";

export interface DBUser {
  id: string;
  email: string;
  nombre: string;
  role: UserRole;
  created_at: string;
}

export interface ModuloRevision {
  obligacionId: string;
  obligacion: string;
  aprobado: boolean | null;
  observacion: string;
}

export interface Submission {
  id: string;
  contratista_id: string;
  contratista_nombre: string;
  profile_data: UserProfile;
  payment_data: Payment;
  estado: SubmissionState;
  modulos_revision: ModuloRevision[];
  observacion_general: string;
  fecha_envio: string;
  fecha_revision: string | null;
}

export interface DBNotification {
  id: string;
  destinatario_id: string;
  titulo: string;
  mensaje: string;
  leido: boolean;
  fecha: string;
  tipo: "info" | "aprobado" | "rechazado" | "nuevo_envio";
}

// ─── User profiles ────────────────────────────────────────────────────────────

export async function getUserProfile(id: string): Promise<DBUser | null> {
  const { data } = await supabase
    .from("user_profiles")
    .select("*")
    .eq("id", id)
    .single();
  return data ?? null;
}

export async function upsertUserProfile(
  id: string,
  email: string,
  nombre: string,
  role: UserRole = "contratista"
): Promise<void> {
  await supabase
    .from("user_profiles")
    .upsert({ id, email, nombre, role }, { onConflict: "id", ignoreDuplicates: true });
}

export async function getAllAdmins(): Promise<DBUser[]> {
  const { data } = await supabase
    .from("user_profiles")
    .select("*")
    .eq("role", "admin");
  return data ?? [];
}

// ─── Submissions ──────────────────────────────────────────────────────────────

export async function createSubmission(
  contratistaId: string,
  contratistaNombre: string,
  profile: UserProfile,
  payment: Payment
): Promise<string | null> {
  const modulos: ModuloRevision[] = profile.obligacionesContractuales.map((ob) => ({
    obligacionId: ob.id,
    obligacion: ob.obligacion,
    aprobado: null,
    observacion: "",
  }));

  const { data, error } = await supabase
    .from("submissions")
    .insert({
      contratista_id: contratistaId,
      contratista_nombre: contratistaNombre,
      profile_data: profile,
      payment_data: payment,
      estado: "pendiente",
      modulos_revision: modulos,
      observacion_general: "",
    })
    .select("id")
    .single();

  if (error) {
    console.error("createSubmission error:", error.message);
    return null;
  }
  return data?.id ?? null;
}

export async function getMySubmissions(contratistaId: string): Promise<Submission[]> {
  const { data } = await supabase
    .from("submissions")
    .select("*")
    .eq("contratista_id", contratistaId)
    .order("fecha_envio", { ascending: false });
  return data ?? [];
}

export async function getAllSubmissions(): Promise<Submission[]> {
  const { data } = await supabase
    .from("submissions")
    .select("*")
    .order("fecha_envio", { ascending: false });
  return data ?? [];
}

export async function getSubmission(id: string): Promise<Submission | null> {
  const { data } = await supabase
    .from("submissions")
    .select("*")
    .eq("id", id)
    .single();
  return data ?? null;
}

export async function updateSubmissionReview(
  id: string,
  modulos: ModuloRevision[],
  observacionGeneral: string,
  estado: SubmissionState
): Promise<boolean> {
  const { error } = await supabase
    .from("submissions")
    .update({
      modulos_revision: modulos,
      observacion_general: observacionGeneral,
      estado,
      fecha_revision: new Date().toISOString(),
    })
    .eq("id", id);
  return !error;
}

// ─── Notifications ────────────────────────────────────────────────────────────

export async function createNotification(
  destinatarioId: string,
  titulo: string,
  mensaje: string,
  tipo: DBNotification["tipo"] = "info"
): Promise<void> {
  await supabase
    .from("notifications")
    .insert({ destinatario_id: destinatarioId, titulo, mensaje, tipo });
}

export async function getMyNotifications(userId: string): Promise<DBNotification[]> {
  const { data } = await supabase
    .from("notifications")
    .select("*")
    .eq("destinatario_id", userId)
    .order("fecha", { ascending: false })
    .limit(50);
  return data ?? [];
}

export async function markNotificationRead(id: string): Promise<void> {
  await supabase.from("notifications").update({ leido: true }).eq("id", id);
}

export async function markAllRead(userId: string): Promise<void> {
  await supabase
    .from("notifications")
    .update({ leido: true })
    .eq("destinatario_id", userId)
    .eq("leido", false);
}
