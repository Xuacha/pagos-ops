const { getDefaultConfig } = require("expo/metro-config");

const config = getDefaultConfig(__dirname);

// Enable web support
config.resolver.platforms = ["ios", "android", "native", "web"];

// Resolve .web.ts / .web.tsx variants first on web platform
config.resolver.sourceExts = [
  "web.tsx",
  "web.ts",
  "web.jsx",
  "web.js",
  ...config.resolver.sourceExts,
];

module.exports = config;
