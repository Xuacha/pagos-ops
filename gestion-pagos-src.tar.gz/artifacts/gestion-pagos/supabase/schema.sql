-- ============================================================
-- GESTIÓN DE PAGOS FUTP  –  Supabase Schema
-- Ejecuta este archivo en: Supabase Dashboard → SQL Editor
-- ============================================================

-- 1. PERFILES DE USUARIO (rol, nombre)
CREATE TABLE IF NOT EXISTS public.user_profiles (
  id       UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email    TEXT NOT NULL,
  nombre   TEXT NOT NULL DEFAULT '',
  role     TEXT NOT NULL DEFAULT 'contratista'
             CHECK (role IN ('contratista', 'admin')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "user_profiles: own read" ON public.user_profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "user_profiles: own insert" ON public.user_profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "user_profiles: own update" ON public.user_profiles
  FOR UPDATE USING (auth.uid() = id);

-- Admins can read all profiles
CREATE POLICY "user_profiles: admin read all" ON public.user_profiles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.user_profiles up
      WHERE up.id = auth.uid() AND up.role = 'admin'
    )
  );

-- ============================================================
-- 2. ENVÍOS / FORMULARIOS
CREATE TABLE IF NOT EXISTS public.submissions (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contratista_id      UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  contratista_nombre  TEXT NOT NULL DEFAULT '',
  profile_data        JSONB NOT NULL,
  payment_data        JSONB NOT NULL,
  estado              TEXT NOT NULL DEFAULT 'pendiente'
                        CHECK (estado IN ('pendiente', 'aprobado', 'rechazado_parcial')),
  modulos_revision    JSONB NOT NULL DEFAULT '[]',
  observacion_general TEXT NOT NULL DEFAULT '',
  fecha_envio         TIMESTAMPTZ DEFAULT NOW(),
  fecha_revision      TIMESTAMPTZ
);

ALTER TABLE public.submissions ENABLE ROW LEVEL SECURITY;

-- Contratista: solo sus propios envíos
CREATE POLICY "submissions: contratista own" ON public.submissions
  FOR ALL USING (auth.uid() = contratista_id);

-- Admin: ve todos
CREATE POLICY "submissions: admin all" ON public.submissions
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.user_profiles up
      WHERE up.id = auth.uid() AND up.role = 'admin'
    )
  );

-- ============================================================
-- 3. NOTIFICACIONES
CREATE TABLE IF NOT EXISTS public.notifications (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  destinatario_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  titulo          TEXT NOT NULL,
  mensaje         TEXT NOT NULL,
  leido           BOOLEAN NOT NULL DEFAULT FALSE,
  fecha           TIMESTAMPTZ DEFAULT NOW(),
  tipo            TEXT NOT NULL DEFAULT 'info'
                    CHECK (tipo IN ('info', 'aprobado', 'rechazado', 'nuevo_envio'))
);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Cada usuario solo ve sus propias notificaciones
CREATE POLICY "notifications: own" ON public.notifications
  FOR ALL USING (auth.uid() = destinatario_id);

-- ============================================================
-- 4. TRIGGER: crear user_profile automáticamente al registrarse
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO public.user_profiles (id, email, nombre, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'role', 'contratista')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();
