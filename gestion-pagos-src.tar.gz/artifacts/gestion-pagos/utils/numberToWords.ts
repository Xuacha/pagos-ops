const unidades = [
  "", "UN", "DOS", "TRES", "CUATRO", "CINCO", "SEIS", "SIETE", "OCHO", "NUEVE",
  "DIEZ", "ONCE", "DOCE", "TRECE", "CATORCE", "QUINCE", "DIECISÉIS",
  "DIECISIETE", "DIECIOCHO", "DIECINUEVE",
];

const decenas = [
  "", "DIEZ", "VEINTE", "TREINTA", "CUARENTA", "CINCUENTA",
  "SESENTA", "SETENTA", "OCHENTA", "NOVENTA",
];

const centenas = [
  "", "CIEN", "DOSCIENTOS", "TRESCIENTOS", "CUATROCIENTOS", "QUINIENTOS",
  "SEISCIENTOS", "SETECIENTOS", "OCHOCIENTOS", "NOVECIENTOS",
];

function convertirMenorMil(n: number): string {
  if (n === 0) return "";
  if (n < 20) return unidades[n];
  if (n < 100) {
    const d = Math.floor(n / 10);
    const u = n % 10;
    if (n === 21) return "VEINTIÚN";
    if (n >= 21 && n <= 29) return "VEINTI" + unidades[u];
    return decenas[d] + (u > 0 ? " Y " + unidades[u] : "");
  }
  const c = Math.floor(n / 100);
  const resto = n % 100;
  if (n === 100) return "CIEN";
  return centenas[c] + (resto > 0 ? " " + convertirMenorMil(resto) : "");
}

export function numberToWords(n: number): string {
  if (n === 0) return "CERO PESOS";
  if (n < 0) return "MENOS " + numberToWords(-n);

  let result = "";
  const millones = Math.floor(n / 1_000_000);
  const miles = Math.floor((n % 1_000_000) / 1_000);
  const resto = n % 1_000;

  if (millones > 0) {
    if (millones === 1) result += "UN MILLÓN";
    else result += convertirMenorMil(millones) + " MILLONES";
  }
  if (miles > 0) {
    if (result) result += " ";
    if (miles === 1) result += "MIL";
    else result += convertirMenorMil(miles) + " MIL";
  }
  if (resto > 0) {
    if (result) result += " ";
    result += convertirMenorMil(resto);
  }

  return result + " PESOS";
}

export function formatCurrency(n: number): string {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    minimumFractionDigits: 2,
  }).format(n);
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat("es-CO").format(n);
}
