import { Payment, UserProfile } from "@/context/AppContext";
import { ModuloRevision } from "@/lib/db";
import { formatCurrency, formatNumber, numberToWords } from "./numberToWords";

export function buildFutpHtml(
  profile: UserProfile,
  payment: Payment,
  logoBase64?: string,
  modulosRevision?: ModuloRevision[]
): string {
  const valorEjecutado = payment.valorPagoNumeros;
  const totalPagosPrev = payment.actaPagoNumero > 1
    ? payment.valorInicial * 0 // se calcula en el pago
    : 0;
  const valorInicialMasAdiciones = payment.valorInicial + payment.valorAdiciones;
  const valorTotalEjecutado = valorEjecutado;
  const saldoEjecutar = valorInicialMasAdiciones - valorTotalEjecutado;
  const porcentajeEjecucion = valorInicialMasAdiciones > 0
    ? ((valorTotalEjecutado / valorInicialMasAdiciones) * 100).toFixed(2)
    : "0.00";
  const totalAnticipos = (payment.anticipos?.anticipo1 || 0) + (payment.anticipos?.anticipo2 || 0);
  const porAmortizar = totalAnticipos - (payment.amortizaciones || 0);

  const logoHtml = logoBase64
    ? `<img src="${logoBase64}" style="width:80px;height:80px;object-fit:contain;" />`
    : `<div style="width:80px;height:80px;border:1px solid #ccc;display:flex;align-items:center;justify-content:center;font-size:9px;color:#999;">LOGO</div>`;

  const obligacionesRows = profile.obligacionesContractuales.map((ob, idx) => {
    const det = payment.obligacionesDetalle.find(d => d.obligacionId === ob.id);
    const revision = modulosRevision?.find(m => m.obligacionId === ob.id);
    const estadoColor = revision
      ? revision.aprobado === true ? "#22c55e" : revision.aprobado === false ? "#ef4444" : "#f59e0b"
      : "transparent";
    const estadoLabel = revision
      ? revision.aprobado === true ? "✓ Aprobado" : revision.aprobado === false ? "✗ Rechazado" : "Pendiente"
      : "";
    const obsHtml = revision?.observacion
      ? `<div style="margin-top:3px;font-size:7px;color:#ef4444;font-style:italic;">Obs: ${revision.observacion}</div>`
      : "";
    const borderLeft = revision?.aprobado === false ? "border-left:3px solid #ef4444;" : revision?.aprobado === true ? "border-left:3px solid #22c55e;" : "";
    return `
      <tr>
        <td style="border:1px solid #333;padding:4px 6px;vertical-align:top;font-size:8px;width:30%;${borderLeft}">${ob.obligacion}${estadoLabel ? `<div style="font-size:7px;color:${estadoColor};font-weight:bold;margin-top:2px;">${estadoLabel}</div>` : ""}</td>
        <td style="border:1px solid #333;padding:4px 6px;vertical-align:top;font-size:8px;width:35%;">${det?.actividad || ob.actividad}</td>
        <td style="border:1px solid #333;padding:4px 6px;vertical-align:top;font-size:8px;width:35%;">${det?.evidencia || ob.evidencia}${obsHtml}</td>
      </tr>`;
  }).join("");

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: Arial, sans-serif; font-size:9px; color:#000; background:#fff; }
  .page { width:210mm; min-height:297mm; padding:10mm 12mm; margin:0 auto; }
  .header-table { width:100%; border-collapse:collapse; border:1px solid #333; margin-bottom:0; }
  .header-table td { border:1px solid #333; padding:4px 6px; vertical-align:middle; }
  .header-title { text-align:center; font-weight:bold; font-size:11px; }
  .header-sub { font-size:8px; }
  .section-title { background:#2c5f9e; color:white; font-weight:bold; text-align:center; padding:3px; margin:4px 0 0 0; font-size:9px; }
  .data-table { width:100%; border-collapse:collapse; }
  .data-table td { border:1px solid #333; padding:3px 5px; font-size:8px; vertical-align:middle; }
  .label { font-weight:bold; background:#eef1f6; width:35%; }
  .sello-box { border:2px solid #333; width:120px; height:70px; display:inline-block; text-align:center; padding:5px; font-size:8px; font-weight:bold; vertical-align:middle; }
  .finance-table { width:100%; border-collapse:collapse; }
  .finance-table td { border:1px solid #333; padding:3px 5px; font-size:8px; }
  .finance-label { font-weight:bold; background:#eef1f6; }
  .declaration { font-size:7.5px; line-height:1.5; text-align:justify; margin-top:4px; }
  .sign-table { width:100%; border-collapse:collapse; margin-top:10px; }
  .sign-table td { border:1px solid #333; padding:4px; text-align:center; font-size:8px; height:50px; vertical-align:bottom; }
  .blue-row { background:#2c5f9e; color:white; font-weight:bold; }
  @media print { .page { padding:8mm; } }
</style>
</head>
<body>
<div class="page">

<!-- HEADER -->
<table class="header-table">
  <tr>
    <td style="width:80px;text-align:center;padding:4px;">
      ${logoHtml}
    </td>
    <td style="text-align:center;">
      <div style="font-size:10px;color:#2c5f9e;font-weight:bold;">GESTIÓN FINANCIERA</div>
      <div class="header-title">FORMATO ÚNICO DE TRAMITE DE PAGO</div>
    </td>
    <td style="width:140px;">
      <div style="font-size:8px;"><b>CÓDIGO:</b> GF-FR-001</div>
      <div style="font-size:8px;"><b>VERSIÓN:</b> 4</div>
      <div style="font-size:8px;"><b>FECHA DE APROBACIÓN:</b> 16/03/2026</div>
    </td>
  </tr>
</table>

<!-- CONTRATO Y PERIODO -->
<table class="header-table" style="margin-top:2px;">
  <tr>
    <td class="label" style="width:25%;font-size:8px;">No. CONTRATO Y FECHA SUSCRIPCIÓN</td>
    <td style="width:25%;font-size:9px;font-weight:bold;">${profile.numeroContrato} - ${profile.fechaSuscripcion}</td>
    <td class="label" style="width:15%;">TIPO DE CONTRATO</td>
    <td style="font-size:9px;font-weight:bold;">${profile.tipoContrato}</td>
  </tr>
  <tr>
    <td class="label">PERIODO CERTIFICADO</td>
    <td colspan="3">
      <span style="font-weight:bold;">DESDE</span>&nbsp;&nbsp;<span style="font-weight:bold;font-size:9px;">${payment.periodoDesde}</span>
      &nbsp;&nbsp;&nbsp;&nbsp;
      <span style="font-weight:bold;">HASTA</span>&nbsp;&nbsp;<span style="font-weight:bold;font-size:9px;">${payment.periodoHasta}</span>
    </td>
  </tr>
</table>

<!-- SECCIÓN I -->
<div class="section-title">I. DATOS DEL CONTRATO</div>
<table class="data-table">
  <tr>
    <td class="label">Unidad ejecutora</td>
    <td colspan="3">${profile.secretaria}</td>
    <td rowspan="8" style="width:120px;text-align:center;vertical-align:middle;padding:8px;">
      <div class="sello-box">
        <div style="font-size:7px;color:#555;">Espacio para sello</div>
        <div style="margin-top:2px;font-size:7px;">Reserva presupuestal</div>
        <div style="font-size:8px;">${profile.reservaPresupuestal ? "Sí" : "No"}</div>
        <div style="margin-top:4px;font-size:7px;">Vo.Bo Dir. Presupuesto</div>
        <div style="margin-top:12px;border-top:1px solid #999;font-size:7px;padding-top:2px;">Firma</div>
      </div>
    </td>
  </tr>
  <tr>
    <td class="label">Nombre Contratista</td>
    <td colspan="3">${profile.nombreContratista}</td>
  </tr>
  <tr>
    <td class="label">No. Identificación (CC – NIT)</td>
    <td colspan="3">${profile.numeroDocumento}</td>
  </tr>
  <tr>
    <td class="label">Objeto Contractual</td>
    <td colspan="3" style="white-space:pre-wrap;">${profile.objetoContractual}</td>
  </tr>
  <tr>
    <td class="label">Valor total del Contrato*</td>
    <td>${formatNumber(profile.valorTotalContrato)}</td>
    <td class="label" style="width:20%;">Reserva presupuestal</td>
    <td>${profile.reservaPresupuestal ? "Sí" : "No"}</td>
  </tr>
  <tr>
    <td class="label">Plazo total Contrato**</td>
    <td colspan="3">${profile.plazoContrato}</td>
  </tr>
  <tr>
    <td class="label">Acta de pago Número</td>
    <td>${payment.actaPagoNumero}</td>
    <td class="label">Valor del pago en numeros</td>
    <td style="font-weight:bold;">${formatNumber(payment.valorPagoNumeros)}</td>
  </tr>
  <tr>
    <td class="label">Valor del pago en letras</td>
    <td colspan="3" style="font-weight:bold;">${payment.valorPagoLetras || numberToWords(payment.valorPagoNumeros)}</td>
  </tr>
  <tr>
    <td class="label">No. CRP y fecha de expedición</td>
    <td colspan="3">${profile.noCrpFecha}</td>
    <td></td>
  </tr>
  <tr>
    <td class="label">No. Del rubro de CRP</td>
    <td colspan="3">${profile.noRubroCrp}</td>
    <td></td>
  </tr>
  <tr>
    <td class="label">Fecha aprobación garantía (Si aplica)</td>
    <td colspan="3">${profile.fechaGarantia}</td>
    <td></td>
  </tr>
  <tr>
    <td class="label">Fecha de Inicio contrato:</td>
    <td>${profile.fechaInicioContrato}</td>
    <td class="label">Fecha de Terminación contrato:</td>
    <td>${profile.fechaTerminacionContrato}</td>
    <td></td>
  </tr>
  <tr>
    <td class="label">Dependencia:</td>
    <td colspan="3">${profile.dependencia}</td>
    <td></td>
  </tr>
  <tr>
    <td class="label">Supervisor – Cargo:</td>
    <td colspan="3">${profile.supervisorCargo}</td>
    <td></td>
  </tr>
  <tr>
    <td class="label">Nombre de entidad financiera para pago</td>
    <td>${profile.entidadFinanciera}</td>
    <td class="label">Actividad economica CIIU</td>
    <td>${profile.actividadEconomicaCIIU}</td>
    <td></td>
  </tr>
  <tr>
    <td class="label">Numero de cuenta</td>
    <td>${profile.numeroCuenta}</td>
    <td class="label">Regimen en ventas</td>
    <td>${profile.regimenVentas}</td>
    <td></td>
  </tr>
  <tr>
    <td class="label">Tipo de cuenta</td>
    <td>${profile.tipoCuenta}</td>
    <td class="label">No. Factura</td>
    <td>${profile.noFactura}</td>
    <td></td>
  </tr>
</table>

<!-- SECCIÓN II -->
<div class="section-title">II. CUMPLIMIENTO SEGÚN CONTRATO.</div>
<table class="data-table">
  <tr class="blue-row">
    <td style="width:30%;color:white;font-weight:bold;font-size:8px;padding:4px;">OBLIGACIONES CONTRACTUALES</td>
    <td style="width:35%;color:white;font-weight:bold;font-size:8px;padding:4px;">ACTIVIDADES REALIZADAS EN EL PERIODO<br/><span style="font-size:7px;font-weight:normal;">(Descripción cuantitativa y cualitativa de las actividades desarrolladas para cumplir la obligación contractual)</span></td>
    <td style="width:35%;color:white;font-weight:bold;font-size:8px;padding:4px;">EVIDENCIA VERIFICABLE<br/><span style="font-size:7px;font-weight:normal;">(Referir la ubicación de los soportes sin acompañarlos físicamente, los cuales integran el archivo del área correspondiente)</span></td>
  </tr>
  ${obligacionesRows}
</table>

<!-- SECCIÓN III -->
<div class="section-title">III. APORTES AL SISTEMA DE SEGURIDAD SOCIAL INTEGRAL</div>
<table class="data-table">
  <tr>
    <td class="label" style="width:20%;">Periodo de pago</td>
    <td style="width:30%;">${payment.periodoPagoSeguridad}</td>
    <td class="label" style="width:25%;">¿LE HAN RECONOCIDO PENSION?</td>
    <td>${profile.lePaganPension ? "Sí" : "No"}</td>
  </tr>
  <tr>
    <td class="label">No. Planilla</td>
    <td>${payment.noPlanilla}</td>
    <td class="label">Entidad que lo reconoció:</td>
    <td>${profile.entidadPension}</td>
  </tr>
  <tr>
    <td class="label">ITEM</td>
    <td class="label">ENTIDAD</td>
    <td class="label" colspan="2">¿LA ADMINISTRACIÓN MUNICIPAL REALIZA SUS APORTES DE ARL (Riesgo)</td>
  </tr>
  <tr>
    <td>SALUD</td>
    <td>${profile.salud}</td>
    <td colspan="2" rowspan="3" style="vertical-align:middle;">
      <div>${profile.municipioRealiza ? "Sí" : "No"}</div>
      <div style="margin-top:4px;"><b>No. De Planilla:</b> ${payment.noPlanilla}</div>
    </td>
  </tr>
  <tr>
    <td>PENSIÓN</td>
    <td>${profile.pension}</td>
  </tr>
  <tr>
    <td>ARL</td>
    <td>${profile.arl}</td>
  </tr>
</table>

<div style="margin-top:6px;border-top:1px solid #333;"></div>

<!-- SECCIÓN IV -->
<div class="section-title">IV. BALANCE FINANCIERO DEL CONTRATO</div>
<table style="width:100%;border-collapse:collapse;">
  <tr>
    <td style="width:50%;vertical-align:top;">
      <table class="finance-table" style="width:100%;">
        <tr class="blue-row"><td colspan="2" style="color:white;font-weight:bold;font-size:8px;padding:3px;">INFORMACIÓN FINANCIERA</td></tr>
        <tr><td class="finance-label" style="font-size:8px;">VALOR INICIAL</td><td style="font-size:8px;">$ ${formatNumber(payment.valorInicial)},00</td></tr>
        <tr><td class="finance-label" style="font-size:8px;">VALOR ADICIONES</td><td style="font-size:8px;">$ ${payment.valorAdiciones > 0 ? formatNumber(payment.valorAdiciones) + ",00" : "-"}</td></tr>
        <tr><td class="finance-label" style="font-size:8px;">VALOR INICIAL MAS ADICIONES</td><td style="font-size:8px;">$ ${formatNumber(valorInicialMasAdiciones)},00</td></tr>
        <tr><td class="finance-label" style="font-size:8px;">VALOR TOTAL EJECUTADO</td><td style="font-size:8px;">$ ${formatNumber(valorTotalEjecutado)},00</td></tr>
        <tr><td class="finance-label" style="font-size:8px;">PORCENTAJE DE EJECUCIÓN</td><td style="font-size:8px;">${porcentajeEjecucion}%</td></tr>
        <tr><td class="finance-label" style="font-size:8px;">SALDO POR EJECUTAR</td><td style="font-size:8px;">$ ${formatNumber(saldoEjecutar)},00</td></tr>
      </table>
    </td>
    <td style="width:50%;vertical-align:top;padding-left:6px;">
      <table class="finance-table" style="width:100%;">
        <tr class="blue-row"><td colspan="2" style="color:white;font-weight:bold;font-size:8px;padding:3px;">PAGO ANTICIPADO</td></tr>
        <tr><td class="finance-label" style="font-size:8px;">ANTICIPO 1</td><td style="font-size:8px;">${payment.anticipos?.anticipo1 > 0 ? formatNumber(payment.anticipos.anticipo1) : ""}</td></tr>
        <tr><td class="finance-label" style="font-size:8px;">ANTICIPO 2</td><td style="font-size:8px;">${payment.anticipos?.anticipo2 > 0 ? formatNumber(payment.anticipos.anticipo2) : ""}</td></tr>
        <tr><td class="finance-label" style="font-size:8px;">TOTAL ANTICIPOS</td><td style="font-size:8px;">${formatNumber(totalAnticipos)}</td></tr>
        <tr><td class="finance-label" style="font-size:8px;">AMORTIZACIONES</td><td style="font-size:8px;">${payment.amortizaciones > 0 ? formatNumber(payment.amortizaciones) : ""}</td></tr>
        <tr><td class="finance-label" style="font-size:8px;">POR AMORTIZAR</td><td style="font-size:8px;">${formatNumber(porAmortizar)}</td></tr>
      </table>
    </td>
  </tr>
</table>

<!-- SECCIÓN V -->
<div class="section-title">V. DECLARACIÓN ESPECIAL</div>
<div class="declaration">
  El contratista declara que toda la información relacionada en el presente informe, corresponde fidedignamente a todas las actividades ejecutadas dentro del respectivo periodo, así como la información de las Entidades a las que aporta al Sistema General de Seguridad Social Integral – SGSSI.
  <br/><br/>
  La supervisión del contrato verificó el cumplimiento por parte del contratista con respecto a los aportes al sistema de seguridad social en salud, pensión y riesgos labores, de conformidad con la normatividad vigente, así como cumplimiento de las actividades a cargo del contratista y toda la información registrada en el presente documento, también certifica que todos los documentos de la ejecución contractual expedidos a la fecha están publicados en el SECOP II.
  <br/><br/>
  En caso de que el supervisor del contrato se ausente de manera temporal y sea designado un supervisor suplente, en las firmas de supervisión se deberá especificar de manera clara el nombre del supervisor encargado, cargo, documento de identidad y el período exacto durante el cual ejerció dicha función, indicando las fechas de inicio y finalización del encargo.
</div>

<!-- FIRMAS -->
<table class="sign-table" style="margin-top:8px;">
  <tr>
    <td style="width:33%;">
      <div style="border-top:1px solid #333;margin-bottom:2px;"></div>
      <div><b>FIRMA CONTRATISTA</b></div>
      <div>${profile.nombreContratista}</div>
      <div>CC: ${profile.numeroDocumento}</div>
    </td>
    <td style="width:33%;">
      <div style="border-top:1px solid #333;margin-bottom:2px;"></div>
      <div><b>FIRMA SUPERVISOR</b></div>
      <div>${profile.supervisorCargo}</div>
    </td>
    <td style="width:33%;">
      <div style="border-top:1px solid #333;margin-bottom:2px;"></div>
      <div><b>REVISADO POR</b></div>
      <div>Coordinador Financiero</div>
    </td>
  </tr>
</table>

</div>
</body>
</html>`;
}

export function buildRetefuenteHtml(profile: UserProfile, payment: Payment, logoBase64?: string): string {
  const baseGravable = payment.valorPagoNumeros;
  const porcentajeRetefuente = 0.04;
  const valorRetefuente = Math.round(baseGravable * porcentajeRetefuente);
  const valorNeto = baseGravable - valorRetefuente;

  const logoHtml = logoBase64
    ? `<img src="${logoBase64}" style="width:80px;height:80px;object-fit:contain;" />`
    : `<div style="width:80px;height:80px;border:1px solid #ccc;display:flex;align-items:center;justify-content:center;font-size:9px;color:#999;">LOGO</div>`;

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: Arial, sans-serif; font-size:9px; color:#000; background:#fff; }
  .page { width:210mm; min-height:297mm; padding:10mm 12mm; margin:0 auto; }
  .header-table { width:100%; border-collapse:collapse; border:1px solid #333; }
  .header-table td { border:1px solid #333; padding:4px 6px; }
  .section-title { background:#2c5f9e; color:white; font-weight:bold; text-align:center; padding:4px; margin:6px 0 0 0; font-size:9px; }
  .data-table { width:100%; border-collapse:collapse; }
  .data-table td { border:1px solid #333; padding:4px 6px; font-size:8px; }
  .label { font-weight:bold; background:#eef1f6; }
  .total-row { background:#2c5f9e; color:white; font-weight:bold; }
  .sign-table { width:100%; border-collapse:collapse; margin-top:20px; }
  .sign-table td { padding:4px; text-align:center; font-size:8px; }
</style>
</head>
<body>
<div class="page">

<table class="header-table">
  <tr>
    <td style="width:80px;text-align:center;">${logoHtml}</td>
    <td style="text-align:center;">
      <div style="font-size:10px;color:#2c5f9e;font-weight:bold;">GESTIÓN FINANCIERA</div>
      <div style="font-weight:bold;font-size:12px;">CERTIFICADO DE RETENCIÓN EN LA FUENTE</div>
      <div style="font-size:9px;">Concepto: Servicios Generales / Honorarios</div>
    </td>
    <td style="width:140px;">
      <div><b>CÓDIGO:</b> GF-FR-002</div>
      <div><b>VERSIÓN:</b> 1</div>
      <div><b>FECHA:</b> ${new Date().toLocaleDateString("es-CO")}</div>
    </td>
  </tr>
</table>

<div class="section-title">DATOS DEL AGENTE RETENEDOR</div>
<table class="data-table">
  <tr>
    <td class="label" style="width:35%;">Entidad / Agente Retenedor</td>
    <td>ALCALDÍA MUNICIPAL</td>
  </tr>
  <tr>
    <td class="label">NIT del Agente</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td class="label">Dirección</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td class="label">Ciudad</td>
    <td>&nbsp;</td>
  </tr>
</table>

<div class="section-title">DATOS DEL RETENIDO (CONTRATISTA)</div>
<table class="data-table">
  <tr>
    <td class="label" style="width:35%;">Nombre o Razón Social</td>
    <td>${profile.nombreContratista}</td>
  </tr>
  <tr>
    <td class="label">NIT / C.C.</td>
    <td>${profile.numeroDocumento}</td>
  </tr>
  <tr>
    <td class="label">Concepto</td>
    <td>SERVICIOS (HONORARIOS) - ${profile.tipoContrato}</td>
  </tr>
  <tr>
    <td class="label">No. Contrato</td>
    <td>${profile.numeroContrato}</td>
  </tr>
  <tr>
    <td class="label">Acta de Pago No.</td>
    <td>${payment.actaPagoNumero}</td>
  </tr>
  <tr>
    <td class="label">Periodo</td>
    <td>${payment.periodoDesde} - ${payment.periodoHasta}</td>
  </tr>
</table>

<div class="section-title">LIQUIDACIÓN DE LA RETENCIÓN</div>
<table class="data-table">
  <tr>
    <td class="label" style="width:50%;">Base Gravable (Valor del Pago)</td>
    <td style="text-align:right;">${formatCurrency(baseGravable)}</td>
  </tr>
  <tr>
    <td class="label">Tarifa de Retención en la Fuente</td>
    <td style="text-align:right;">${(porcentajeRetefuente * 100).toFixed(0)}%</td>
  </tr>
  <tr>
    <td class="label">Valor Retenido</td>
    <td style="text-align:right;font-weight:bold;">${formatCurrency(valorRetefuente)}</td>
  </tr>
  <tr class="total-row">
    <td style="color:white;">VALOR NETO A PAGAR</td>
    <td style="text-align:right;color:white;">${formatCurrency(valorNeto)}</td>
  </tr>
</table>

<div class="section-title">DECLARACIÓN</div>
<div style="font-size:8px;line-height:1.6;text-align:justify;padding:6px;border:1px solid #333;">
  Certificamos que el presente documento corresponde a la retención practicada en la fuente durante el periodo señalado, de conformidad con las disposiciones del Estatuto Tributario y demás normas vigentes.
</div>

<table class="sign-table">
  <tr>
    <td style="width:50%;">
      <div style="height:60px;"></div>
      <div style="border-top:1px solid #333;"></div>
      <div><b>AGENTE RETENEDOR</b></div>
      <div>ALCALDÍA MUNICIPAL</div>
    </td>
    <td style="width:50%;">
      <div style="border:2px solid #555;height:80px;display:flex;align-items:center;justify-content:center;font-size:9px;color:#777;">
        <div style="text-align:center;">
          <div style="font-weight:bold;">ESPACIO PARA SELLO</div>
          <div>DE RADICADO</div>
        </div>
      </div>
    </td>
  </tr>
</table>

</div>
</body>
</html>`;
}

export function buildAdicionHtml(profile: UserProfile, payment: Payment, logoBase64?: string): string {
  const logoHtml = logoBase64
    ? `<img src="${logoBase64}" style="width:80px;height:80px;object-fit:contain;" />`
    : `<div style="width:80px;height:80px;border:1px solid #ccc;display:flex;align-items:center;justify-content:center;font-size:9px;color:#999;">LOGO</div>`;

  const valorTotalConAdicion = (profile.valorTotalContrato) + (payment.adicionValor || 0);

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: Arial, sans-serif; font-size:9px; color:#000; background:#fff; }
  .page { width:210mm; min-height:297mm; padding:10mm 12mm; margin:0 auto; }
  .header-table { width:100%; border-collapse:collapse; border:1px solid #333; }
  .header-table td { border:1px solid #333; padding:4px 6px; }
  .section-title { background:#2c5f9e; color:white; font-weight:bold; text-align:center; padding:4px; margin:6px 0 0 0; font-size:9px; }
  .data-table { width:100%; border-collapse:collapse; }
  .data-table td { border:1px solid #333; padding:4px 6px; font-size:8px; }
  .label { font-weight:bold; background:#eef1f6; }
  .highlight { background:#fffde7; font-weight:bold; }
  .sign-table { width:100%; border-collapse:collapse; margin-top:20px; }
  .sign-table td { padding:8px; text-align:center; font-size:8px; height:60px; vertical-align:bottom; }
</style>
</head>
<body>
<div class="page">

<table class="header-table">
  <tr>
    <td style="width:80px;text-align:center;">${logoHtml}</td>
    <td style="text-align:center;">
      <div style="font-size:10px;color:#2c5f9e;font-weight:bold;">GESTIÓN FINANCIERA</div>
      <div style="font-weight:bold;font-size:12px;">FORMATO DE ADICIÓN AL CONTRATO</div>
      <div style="font-size:9px;">Acta de Modificación / Adición</div>
    </td>
    <td style="width:140px;">
      <div><b>CÓDIGO:</b> GF-FR-003</div>
      <div><b>VERSIÓN:</b> 1</div>
      <div><b>FECHA:</b> ${new Date().toLocaleDateString("es-CO")}</div>
    </td>
  </tr>
</table>

<div class="section-title">I. IDENTIFICACIÓN DEL CONTRATO</div>
<table class="data-table">
  <tr>
    <td class="label" style="width:35%;">No. Contrato y Fecha Suscripción</td>
    <td>${profile.numeroContrato} - ${profile.fechaSuscripcion}</td>
    <td class="label" style="width:20%;">Tipo de Contrato</td>
    <td>${profile.tipoContrato}</td>
  </tr>
  <tr>
    <td class="label">Unidad Ejecutora</td>
    <td colspan="3">${profile.secretaria}</td>
  </tr>
  <tr>
    <td class="label">Nombre Contratista</td>
    <td colspan="3">${profile.nombreContratista}</td>
  </tr>
  <tr>
    <td class="label">No. Identificación (CC – NIT)</td>
    <td colspan="3">${profile.numeroDocumento}</td>
  </tr>
  <tr>
    <td class="label">Objeto Contractual</td>
    <td colspan="3">${profile.objetoContractual}</td>
  </tr>
  <tr>
    <td class="label">Supervisor – Cargo</td>
    <td colspan="3">${profile.supervisorCargo}</td>
  </tr>
</table>

<div class="section-title">II. CONDICIONES DE LA ADICIÓN</div>
<table class="data-table">
  <tr>
    <td class="label" style="width:35%;">Valor Inicial del Contrato</td>
    <td>${formatCurrency(profile.valorTotalContrato)}</td>
    <td class="label" style="width:20%;">Plazo Inicial</td>
    <td>${profile.plazoContrato}</td>
  </tr>
  <tr>
    <td class="label highlight">Valor de la Adición</td>
    <td class="highlight">${formatCurrency(payment.adicionValor || 0)}</td>
    <td class="label highlight">Adición de Plazo</td>
    <td class="highlight">${payment.adicionPlazo || "N/A"}</td>
  </tr>
  <tr>
    <td class="label" style="background:#c8e6c9;">Nuevo Valor Total del Contrato</td>
    <td style="background:#c8e6c9;font-weight:bold;">${formatCurrency(valorTotalConAdicion)}</td>
    <td class="label" style="background:#c8e6c9;">Nueva Fecha de Terminación</td>
    <td style="background:#c8e6c9;font-weight:bold;">${payment.adicionFechaFin || profile.fechaTerminacionContrato}</td>
  </tr>
  <tr>
    <td class="label">Fecha de Inicio (Adición)</td>
    <td>${payment.adicionFechaInicio || ""}</td>
    <td class="label">Fecha de Fin (Adición)</td>
    <td>${payment.adicionFechaFin || ""}</td>
  </tr>
</table>

<div class="section-title">III. JUSTIFICACIÓN DE LA ADICIÓN</div>
<table class="data-table">
  <tr>
    <td style="min-height:80px;padding:10px;font-size:8px;">
      La presente adición se realiza con el fin de garantizar la continuidad en la prestación de los servicios objeto del contrato, dado el requerimiento adicional de actividades para el cumplimiento de los objetivos institucionales de la entidad.
      <br/><br/>
      <i>(Espacio para descripción específica de la justificación)</i>
    </td>
  </tr>
</table>

<div class="section-title">IV. BALANCE FINANCIERO ACTUALIZADO</div>
<table class="data-table">
  <tr>
    <td class="label" style="width:35%;">Valor Inicial</td>
    <td>${formatCurrency(profile.valorTotalContrato)}</td>
    <td class="label" style="width:20%;">Plazo Inicial</td>
    <td>${profile.plazoContrato}</td>
  </tr>
  <tr>
    <td class="label">Valor Adición</td>
    <td>${formatCurrency(payment.adicionValor || 0)}</td>
    <td class="label">Plazo Adición</td>
    <td>${payment.adicionPlazo || "0"}</td>
  </tr>
  <tr>
    <td class="label" style="background:#c8e6c9;">Total Nuevo Valor</td>
    <td style="background:#c8e6c9;font-weight:bold;">${formatCurrency(valorTotalConAdicion)}</td>
    <td class="label" style="background:#c8e6c9;">Total Nuevo Plazo</td>
    <td style="background:#c8e6c9;font-weight:bold;">${payment.adicionPlazo || profile.plazoContrato}</td>
  </tr>
  <tr>
    <td class="label">Valor Ejecutado (a la fecha)</td>
    <td>${formatCurrency(payment.valorPagoNumeros)}</td>
    <td class="label">Saldo por Ejecutar</td>
    <td>${formatCurrency(valorTotalConAdicion - payment.valorPagoNumeros)}</td>
  </tr>
</table>

<div style="margin-top:8px;border:2px solid #555;padding:8px;text-align:center;">
  <div style="font-size:8px;font-weight:bold;">ESPACIO PARA SELLO DE RADICADO</div>
  <div style="height:50px;"></div>
</div>

<table class="sign-table">
  <tr>
    <td style="border:1px solid #333;">
      <div style="border-top:1px solid #333;"></div>
      <div><b>CONTRATISTA</b></div>
      <div>${profile.nombreContratista}</div>
      <div>CC: ${profile.numeroDocumento}</div>
    </td>
    <td style="border:1px solid #333;">
      <div style="border-top:1px solid #333;"></div>
      <div><b>SUPERVISOR DEL CONTRATO</b></div>
      <div>${profile.supervisorCargo}</div>
    </td>
    <td style="border:1px solid #333;">
      <div style="border-top:1px solid #333;"></div>
      <div><b>ORDENADOR DEL GASTO</b></div>
      <div>Alcalde(sa) Municipal</div>
    </td>
  </tr>
</table>

</div>
</body>
</html>`;
}
