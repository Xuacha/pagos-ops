import * as FileSystem from "expo-file-system";
import * as Print from "expo-print";
import * as Sharing from "expo-sharing";

export async function printAndSharePdf(
  html: string,
  fileName: string
): Promise<void> {
  const { uri } = await Print.printToFileAsync({ html, base64: false });
  const dest = FileSystem.documentDirectory + fileName;
  await FileSystem.moveAsync({ from: uri, to: dest });
  const canShare = await Sharing.isAvailableAsync();
  if (canShare) {
    await Sharing.shareAsync(dest, { mimeType: "application/pdf" });
  } else {
    throw new Error(`PDF guardado en: ${dest}`);
  }
}
