export async function printAndSharePdf(
  html: string,
  _fileName: string
): Promise<void> {
  const w = window.open("", "_blank");
  if (!w) {
    throw new Error("El navegador bloqueó la ventana emergente. Permite ventanas emergentes y vuelve a intentarlo.");
  }
  w.document.write(html);
  w.document.close();
  setTimeout(() => {
    w.focus();
    w.print();
  }, 300);
}
