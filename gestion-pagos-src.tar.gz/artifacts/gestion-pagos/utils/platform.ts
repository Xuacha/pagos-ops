import { Platform } from "react-native";

export const isWeb = Platform.OS === "web";
export const isAndroid = Platform.OS === "android";
export const isIOS = Platform.OS === "ios";
export const isNative = !isWeb;

export async function hapticLight(): Promise<void> {
  if (isWeb) return;
  const Haptics = await import("expo-haptics");
  await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
}

export async function hapticMedium(): Promise<void> {
  if (isWeb) return;
  const Haptics = await import("expo-haptics");
  await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
}

export async function hapticHeavy(): Promise<void> {
  if (isWeb) return;
  const Haptics = await import("expo-haptics");
  await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
}

export async function hapticSuccess(): Promise<void> {
  if (isWeb) return;
  const Haptics = await import("expo-haptics");
  await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
}
